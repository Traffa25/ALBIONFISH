import {
  require_react
} from "./chunk-WYQRYOQT.js";
export default require_react();
