import { createContext, useContext, useState, useEffect, type ReactNode } from 'react';

type Language = 'en' | 'es';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

// Translations
const translations = {
  en: {
    // Navigation
    'nav.dashboard': 'Dashboard',
    'nav.maps': 'Maps',
    'nav.tips': 'Tips',
    'nav.market': 'Market',
    'nav.premium': 'Premium',
    'nav.signin': 'Sign In',
    'nav.settings': 'Settings',
    'nav.upgrade': 'Upgrade to Premium',
    'nav.signout': 'Sign Out',

    // Dashboard
    'dashboard.title': 'Master Albion\'s',
    'dashboard.subtitle': 'Fishing Waters',
    'dashboard.description': 'Advanced tools, AI-powered insights, and real-time market data to maximize your fishing profits in Albion Online. From zone optimization to inventory management, we\'ve got you covered.',
    'dashboard.cta.start': 'Start Fishing Assistant',
    'dashboard.cta.demo': 'View Live Demo',
    'dashboard.stats.caught': 'Total Fish Caught',
    'dashboard.stats.earned': 'Silver Earned',
    'dashboard.stats.zone': 'Best Zone',
    'dashboard.stats.profit': 'Profit Rate',
    'dashboard.features.title': 'Everything You Need to Dominate',
    'dashboard.features.subtitle': 'Comprehensive tools designed specifically for Albion Online fishing optimization',
    'dashboard.feature.maps.title': 'Interactive Maps',
    'dashboard.feature.maps.desc': 'Explore fishing zones across all Albion cities with real-time information',
    'dashboard.feature.calculator.title': 'Profit Calculator',
    'dashboard.feature.calculator.desc': 'Calculate optimal fishing strategies and expected returns',
    'dashboard.feature.ai.title': 'AI Assistant',
    'dashboard.feature.ai.desc': 'Get personalized recommendations and answer to your questions',
    'dashboard.feature.market.title': 'Market Intelligence',
    'dashboard.feature.market.desc': 'Real-time pricing data and market trends analysis',
    'dashboard.premium.title': 'Unlock Premium Features',
    'dashboard.premium.desc': 'Get access to advanced AI recommendations, real-time market alerts, and exclusive fishing strategies',
    'dashboard.premium.cta': 'Upgrade to Premium',

    // Maps
    'maps.title': 'Fishing Maps & Zones',
    'maps.description': 'Explore detailed fishing locations across all Albion Online cities with real-time data and AI-powered recommendations',
    'maps.cities.title': 'Cities Overview',
    'maps.zones.title': 'Fishing Zones',
    'maps.filter.all': 'All Cities',
    'maps.zone.coordinates': 'Coordinates',
    'maps.zone.profit': 'Profit Level',
    'maps.zone.fish': 'Available Fish',
    'maps.zone.resources': 'Additional Resources',
    'maps.zone.viewmap': 'View Detailed Map',
    'maps.interactive.title': 'Interactive World Map',
    'maps.interactive.subtitle': 'Interactive Map Coming Soon',
    'maps.interactive.desc': 'Full interactive map with real-time zone data and AI recommendations',
    'maps.city.thetford.desc': 'Rich fishing grounds with consistent catches',
    'maps.city.bridgewatch.desc': 'Diverse fish species and good profit margins',
    'maps.city.martlock.desc': 'Premium fishing spots with rare catches',
    'maps.city.lymhurst.desc': 'Beginner-friendly waters with steady income',
    'maps.city.fortsterling.desc': 'Balanced fishing experience with good variety',
    'maps.city.caerleon.desc': 'High-risk, high-reward black zone fishing',

    // Market
    'market.title': 'Market Intelligence',
    'market.description': 'Real-time pricing data and AI-powered market analysis for optimal trading decisions',
    'market.gold.title': 'Gold to Silver Exchange',
    'market.gold.rate': 'Current Rate',
    'market.gold.change': '24h Change',
    'market.gold.prediction': 'AI Prediction',
    'market.gold.trend': 'Bullish Trend',
    'market.gold.timeframe': 'Next 48h',
    'market.insights.title': 'AI Market Insights',
    'market.prices.title': 'Live Fish Prices',
    'market.calculator.title': 'Quick Profit Calculator',
    'market.calculator.fish': 'Fish Type',
    'market.calculator.quantity': 'Quantity',
    'market.calculator.city': 'City',
    'market.calculator.calculate': 'Calculate',
    'market.calculator.profit': 'Estimated Profit',
    'market.calculator.based': 'Based on current market prices',

    // Tips
    'tips.title': 'Fishing Tips & Builds',
    'tips.description': 'Master the art of fishing with expert builds, strategies, and AI-powered recommendations',
    'tips.tabs.builds': 'Fishing Builds',
    'tips.tabs.tips': 'Pro Tips',
    'tips.tabs.food': 'Food Guide',
    'tips.ai.title': 'AI-Powered Recommendations',
    'tips.ai.desc': 'Get personalized fishing strategies based on your playstyle, budget, and goals with our advanced AI assistant',
    'tips.ai.cta': 'Get My Custom Strategy',

    // Premium
    'premium.title': 'Dominate Albion\'s',
    'premium.subtitle': 'Fishing Economy',
    'premium.description': 'Join elite fishers who use advanced AI tools and real-time data to maximize their profits and minimize risks',
    'premium.features.title': 'Why Upgrade to Premium?',
    'premium.pricing.title': 'Choose Your Plan',
    'premium.code.title': 'Have a Premium Code?',
    'premium.code.desc': 'Enter your premium activation code to unlock all features instantly',
    'premium.code.placeholder': 'Enter premium code',
    'premium.code.activate': 'Activate Code',
    'premium.testimonials.title': 'What Premium Users Say',
    'premium.faq.title': 'Frequently Asked Questions',

    // Auth Modal
    'auth.welcome': 'Welcome Back',
    'auth.create': 'Create Account',
    'auth.signin.desc': 'Sign in to your AlbionFish account',
    'auth.signup.desc': 'Join the ultimate Albion fishing community',
    'auth.google': 'Continue with Google',
    'auth.discord': 'Continue with Discord',
    'auth.email': 'Or continue with email',
    'auth.name': 'Name',
    'auth.email.label': 'Email',
    'auth.password': 'Password',
    'auth.signin.button': 'Sign In',
    'auth.signup.button': 'Create Account',
    'auth.no.account': 'Don\'t have an account?',
    'auth.have.account': 'Already have an account?',
    'auth.signup.link': 'Sign up',
    'auth.signin.link': 'Sign in',

    // AI Chat
    'chat.title': 'AI Fishing Assistant',
    'chat.welcome': 'Hello! I\'m your AI fishing assistant. I can help you with builds, zone recommendations, market analysis, and answer any Albion Online fishing questions you have. What would you like to know?',
    'chat.placeholder': 'Ask me anything about fishing...',
    'chat.questions': 'Quick questions:',

    // Common
    'common.loading': 'Loading...',
    'common.refresh': 'Refresh',
    'common.updating': 'Updating...',
    'common.save': 'Save',
    'common.cancel': 'Cancel',
    'common.close': 'Close',
    'common.back': 'Back',
    'common.next': 'Next',
    'common.previous': 'Previous',
    'common.search': 'Search',
    'common.filter': 'Filter',
    'common.sort': 'Sort',
    'common.view': 'View',
    'common.edit': 'Edit',
    'common.delete': 'Delete',
    'common.copy': 'Copy',
    'common.share': 'Share'
  },
  es: {
    // Navigation
    'nav.dashboard': 'Panel',
    'nav.maps': 'Mapas',
    'nav.tips': 'Consejos',
    'nav.market': 'Mercado',
    'nav.premium': 'Premium',
    'nav.signin': 'Iniciar Sesión',
    'nav.settings': 'Configuración',
    'nav.upgrade': 'Actualizar a Premium',
    'nav.signout': 'Cerrar Sesión',

    // Dashboard
    'dashboard.title': 'Domina las',
    'dashboard.subtitle': 'Aguas de Albion',
    'dashboard.description': 'Herramientas avanzadas, información impulsada por IA y datos de mercado en tiempo real para maximizar tus ganancias de pesca en Albion Online. Desde optimización de zonas hasta gestión de inventario, te tenemos cubierto.',
    'dashboard.cta.start': 'Iniciar Asistente de Pesca',
    'dashboard.cta.demo': 'Ver Demo en Vivo',
    'dashboard.stats.caught': 'Total de Peces Capturados',
    'dashboard.stats.earned': 'Silver Ganado',
    'dashboard.stats.zone': 'Mejor Zona',
    'dashboard.stats.profit': 'Tasa de Ganancia',
    'dashboard.features.title': 'Todo lo que Necesitas para Dominar',
    'dashboard.features.subtitle': 'Herramientas integrales diseñadas específicamente para la optimización de pesca en Albion Online',
    'dashboard.feature.maps.title': 'Mapas Interactivos',
    'dashboard.feature.maps.desc': 'Explora zonas de pesca en todas las ciudades de Albion con información en tiempo real',
    'dashboard.feature.calculator.title': 'Calculadora de Ganancias',
    'dashboard.feature.calculator.desc': 'Calcula estrategias óptimas de pesca y retornos esperados',
    'dashboard.feature.ai.title': 'Asistente IA',
    'dashboard.feature.ai.desc': 'Obtén recomendaciones personalizadas y respuestas a tus preguntas',
    'dashboard.feature.market.title': 'Inteligencia de Mercado',
    'dashboard.feature.market.desc': 'Datos de precios en tiempo real y análisis de tendencias del mercado',
    'dashboard.premium.title': 'Desbloquea Características Premium',
    'dashboard.premium.desc': 'Obtén acceso a recomendaciones avanzadas de IA, alertas de mercado en tiempo real y estrategias exclusivas de pesca',
    'dashboard.premium.cta': 'Actualizar a Premium',

    // Maps
    'maps.title': 'Mapas y Zonas de Pesca',
    'maps.description': 'Explora ubicaciones detalladas de pesca en todas las ciudades de Albion Online con datos en tiempo real y recomendaciones impulsadas por IA',
    'maps.cities.title': 'Vista General de Ciudades',
    'maps.zones.title': 'Zonas de Pesca',
    'maps.filter.all': 'Todas las Ciudades',
    'maps.zone.coordinates': 'Coordenadas',
    'maps.zone.profit': 'Nivel de Ganancia',
    'maps.zone.fish': 'Peces Disponibles',
    'maps.zone.resources': 'Recursos Adicionales',
    'maps.zone.viewmap': 'Ver Mapa Detallado',
    'maps.interactive.title': 'Mapa Mundial Interactivo',
    'maps.interactive.subtitle': 'Mapa Interactivo Próximamente',
    'maps.interactive.desc': 'Mapa interactivo completo con datos de zona en tiempo real y recomendaciones de IA',
    'maps.city.thetford.desc': 'Ricos terrenos de pesca con capturas consistentes',
    'maps.city.bridgewatch.desc': 'Diversas especies de peces y buenos márgenes de ganancia',
    'maps.city.martlock.desc': 'Lugares de pesca premium con capturas raras',
    'maps.city.lymhurst.desc': 'Aguas amigables para principiantes con ingresos estables',
    'maps.city.fortsterling.desc': 'Experiencia de pesca equilibrada con buena variedad',
    'maps.city.caerleon.desc': 'Pesca de zona negra de alto riesgo y alta recompensa',

    // Market
    'market.title': 'Inteligencia de Mercado',
    'market.description': 'Datos de precios en tiempo real y análisis de mercado impulsado por IA para decisiones comerciales óptimas',
    'market.gold.title': 'Intercambio de Oro a Silver',
    'market.gold.rate': 'Tasa Actual',
    'market.gold.change': 'Cambio 24h',
    'market.gold.prediction': 'Predicción IA',
    'market.gold.trend': 'Tendencia Alcista',
    'market.gold.timeframe': 'Próximas 48h',
    'market.insights.title': 'Perspectivas de Mercado IA',
    'market.prices.title': 'Precios de Peces en Vivo',
    'market.calculator.title': 'Calculadora Rápida de Ganancias',
    'market.calculator.fish': 'Tipo de Pez',
    'market.calculator.quantity': 'Cantidad',
    'market.calculator.city': 'Ciudad',
    'market.calculator.calculate': 'Calcular',
    'market.calculator.profit': 'Ganancia Estimada',
    'market.calculator.based': 'Basado en precios actuales del mercado',

    // Tips
    'tips.title': 'Consejos y Builds de Pesca',
    'tips.description': 'Domina el arte de la pesca con builds expertos, estrategias y recomendaciones impulsadas por IA',
    'tips.tabs.builds': 'Builds de Pesca',
    'tips.tabs.tips': 'Consejos Pro',
    'tips.tabs.food': 'Guía de Comida',
    'tips.ai.title': 'Recomendaciones Impulsadas por IA',
    'tips.ai.desc': 'Obtén estrategias de pesca personalizadas basadas en tu estilo de juego, presupuesto y objetivos con nuestro asistente avanzado de IA',
    'tips.ai.cta': 'Obtener Mi Estrategia Personalizada',

    // Premium
    'premium.title': 'Domina la',
    'premium.subtitle': 'Economía de Pesca de Albion',
    'premium.description': 'Únete a los pescadores élite que usan herramientas avanzadas de IA y datos en tiempo real para maximizar sus ganancias y minimizar riesgos',
    'premium.features.title': '¿Por qué Actualizar a Premium?',
    'premium.pricing.title': 'Elige tu Plan',
    'premium.code.title': '¿Tienes un Código Premium?',
    'premium.code.desc': 'Ingresa tu código de activación premium para desbloquear todas las características al instante',
    'premium.code.placeholder': 'Ingresa código premium',
    'premium.code.activate': 'Activar Código',
    'premium.testimonials.title': 'Lo que Dicen los Usuarios Premium',
    'premium.faq.title': 'Preguntas Frecuentes',

    // Auth Modal
    'auth.welcome': 'Bienvenido de Vuelta',
    'auth.create': 'Crear Cuenta',
    'auth.signin.desc': 'Inicia sesión en tu cuenta de AlbionFish',
    'auth.signup.desc': 'Únete a la comunidad definitiva de pesca de Albion',
    'auth.google': 'Continuar con Google',
    'auth.discord': 'Continuar con Discord',
    'auth.email': 'O continuar con email',
    'auth.name': 'Nombre',
    'auth.email.label': 'Email',
    'auth.password': 'Contraseña',
    'auth.signin.button': 'Iniciar Sesión',
    'auth.signup.button': 'Crear Cuenta',
    'auth.no.account': '¿No tienes una cuenta?',
    'auth.have.account': '¿Ya tienes una cuenta?',
    'auth.signup.link': 'Registrarse',
    'auth.signin.link': 'Iniciar sesión',

    // AI Chat
    'chat.title': 'Asistente IA de Pesca',
    'chat.welcome': '¡Hola! Soy tu asistente de pesca con IA. Puedo ayudarte con builds, recomendaciones de zonas, análisis de mercado y responder cualquier pregunta sobre pesca en Albion Online que tengas. ¿Qué te gustaría saber?',
    'chat.placeholder': 'Pregúntame cualquier cosa sobre pesca...',
    'chat.questions': 'Preguntas rápidas:',

    // Common
    'common.loading': 'Cargando...',
    'common.refresh': 'Actualizar',
    'common.updating': 'Actualizando...',
    'common.save': 'Guardar',
    'common.cancel': 'Cancelar',
    'common.close': 'Cerrar',
    'common.back': 'Atrás',
    'common.next': 'Siguiente',
    'common.previous': 'Anterior',
    'common.search': 'Buscar',
    'common.filter': 'Filtrar',
    'common.sort': 'Ordenar',
    'common.view': 'Ver',
    'common.edit': 'Editar',
    'common.delete': 'Eliminar',
    'common.copy': 'Copiar',
    'common.share': 'Compartir'
  }
};

interface LanguageProviderProps {
  children: ReactNode;
}

export const LanguageProvider = ({ children }: LanguageProviderProps) => {
  const [language, setLanguage] = useState<Language>(() => {
    const saved = localStorage.getItem('albionfish-language');
    return (saved as Language) || 'en';
  });

  useEffect(() => {
    localStorage.setItem('albionfish-language', language);
  }, [language]);

  const t = (key: string): string => {
    return (translations[language] as any)[key] || key;
  };

  const value = {
    language,
    setLanguage,
    t
  };

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};