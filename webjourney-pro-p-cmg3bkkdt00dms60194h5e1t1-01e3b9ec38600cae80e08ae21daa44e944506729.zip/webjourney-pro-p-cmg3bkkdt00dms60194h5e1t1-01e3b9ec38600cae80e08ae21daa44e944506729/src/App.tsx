import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { LanguageProvider } from './contexts/LanguageContext';
import Dashboard from './pages/Dashboard';
import Maps from './pages/Maps';
import Tips from './pages/Tips';
import Premium from './pages/Premium';
import Market from './pages/Market';

function App() {
  return (
    <LanguageProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/maps" element={<Maps />} />
          <Route path="/tips" element={<Tips />} />
          <Route path="/premium" element={<Premium />} />
          <Route path="/market" element={<Market />} />
        </Routes>
      </BrowserRouter>
    </LanguageProvider>
  );
}

export default App;