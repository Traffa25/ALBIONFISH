import { useState, useCallback, useMemo, useEffect } from 'react';
import { MessageCircle, Send, Bot, User, X, Minimize2 } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface Message {
  id: number;
  text: string;
  sender: 'user' | 'ai';
  timestamp: Date;
}

export default function OptimizedAIChat() {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [currentMessage, setCurrentMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const { t, language } = useLanguage();

  // Initialize welcome message after component mounts
  useEffect(() => {
    if (messages.length === 0) {
      setMessages([
        {
          id: 1,
          text: t('chat.welcome'),
          sender: 'ai',
          timestamp: new Date()
        }
      ]);
    }
  }, [t, messages.length]);

  const predefinedQuestions = useMemo(() => {
    return language === 'es' ? [
      "¿Cuál es el mejor build T5 para pesca?",
      "¿Qué zonas son más rentables ahora?",
      "¿Cómo evito gankers mientras pesco?",
      "¿Qué comida usar para pesca T6?"
    ] : [
      "What's the best T5 fishing build?",
      "Which zones are most profitable right now?",
      "How do I avoid gankers while fishing?",
      "What food should I use for T6 fishing?"
    ];
  }, [language]);

  const generateAIResponse = useCallback((question: string) => {
    const lowerQuestion = question.toLowerCase();

    if (language === 'es') {
      const responses: { [key: string]: string } = {
        'build': "Para pesca T5, recomiendo: Caña de Pescar T5 de Tenacidad, cebo Premium Grub, Sopa de Almejas para +22% rendimiento, y Poción Mayor de Pesca. Esta configuración cuesta ~200K silver pero ofrece excelentes retornos en zonas de Bridgewatch o Fort Sterling.",
        'zona': "Actualmente, las Piscinas Elite de Martlock están mostrando los márgenes de ganancia más altos con precios de peces T6+ subiendo 28% esta semana. Sin embargo, considera el mayor riesgo. Para ganancias más seguras, las aguas costeras de Bridgewatch ofrecen rendimientos T5-T6 consistentes con menor competencia.",
        'ganker': "Para evitar gankers: 1) Pesca durante horas de poca actividad, 2) Usa zonas con múltiples rutas de escape, 3) Vigila jugadores rojos en minimapa, 4) Considera pescar en zonas azules durante períodos de alta actividad, 5) Usa equipo ligero en zonas negras.",
        'comida': "Para pesca T6, el Rollo de Salmón proporciona +32% rendimiento de pesca y cuesta ~25K silver. Es el punto ideal para pesca T6-T7. La Tortilla de Dragón (+44% rendimiento) solo vale la pena para pesca T7+ en zona negra debido al costo de 80K silver.",
        'default': "¡Excelente pregunta! Basado en las condiciones actuales del mercado y tus objetivos de pesca, recomendaría enfocarse en zonas T5-T6 para la mejor relación ganancia-riesgo. ¿Te gustaría recomendaciones específicas de zonas o sugerencias de builds?"
      };

      if (lowerQuestion.includes('build') || lowerQuestion.includes('configuración')) return responses.build;
      if (lowerQuestion.includes('zona') || lowerQuestion.includes('rentable') || lowerQuestion.includes('ganancia')) return responses.zona;
      if (lowerQuestion.includes('ganker') || lowerQuestion.includes('evitar') || lowerQuestion.includes('segur')) return responses.ganker;
      if (lowerQuestion.includes('comida') || lowerQuestion.includes('t6') || lowerQuestion.includes('alimento')) return responses.comida;

      return responses.default;
    } else {
      const responses: { [key: string]: string } = {
        'build': "For T5 fishing, I recommend: T5 Fishing Rod of Tenacity, Premium Grub bait, Clam Soup for +22% yield, and Major Fishing Potion. This setup costs ~200K silver but provides excellent returns in Bridgewatch or Fort Sterling zones.",
        'zone': "Currently, Martlock Elite Pools are showing the highest profit margins with T6+ fish prices up 28% this week. However, consider the increased risk. For safer profits, Bridgewatch coastal waters offer consistent T5-T6 yields with lower competition.",
        'ganker': "To avoid gankers: 1) Fish during off-peak hours, 2) Use zones with multiple escape routes, 3) Watch for red players on minimap, 4) Consider fishing in blue zones during high-activity periods, 5) Use lightweight gear in black zones.",
        'food': "For T6 fishing, Salmon Roll provides +32% fishing yield and costs ~25K silver. It's the sweet spot for T6-T7 fishing. Dragon Omelet (+44% yield) is only worth it for T7+ black zone fishing due to the 80K silver cost.",
        'default': "That's a great question! Based on current market conditions and your fishing goals, I'd recommend focusing on T5-T6 zones for the best profit-to-risk ratio. Would you like specific zone recommendations or build suggestions?"
      };

      if (lowerQuestion.includes('build')) return responses.build;
      if (lowerQuestion.includes('zone') || lowerQuestion.includes('profitable')) return responses.zone;
      if (lowerQuestion.includes('ganker') || lowerQuestion.includes('avoid') || lowerQuestion.includes('safe')) return responses.ganker;
      if (lowerQuestion.includes('food') || lowerQuestion.includes('t6')) return responses.food;

      return responses.default;
    }
  }, [language]);

  const sendMessage = useCallback(() => {
    if (!currentMessage.trim()) return;

    const newMessage: Message = {
      id: Date.now(),
      text: currentMessage,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, newMessage]);
    const messageToProcess = currentMessage;
    setCurrentMessage('');
    setIsTyping(true);

    // Optimized AI response with shorter delay
    setTimeout(() => {
      const aiResponse: Message = {
        id: Date.now() + 1,
        text: generateAIResponse(messageToProcess),
        sender: 'ai',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, aiResponse]);
      setIsTyping(false);
    }, 1000);
  }, [currentMessage, generateAIResponse]);

  const handlePredefinedQuestion = useCallback((question: string) => {
    setCurrentMessage(question);
  }, []);

  const handleKeyPress = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  }, [sendMessage]);

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 w-14 h-14 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 rounded-full shadow-lg flex items-center justify-center text-white transition-all duration-300 hover:scale-110 z-50"
        aria-label={t('chat.title')}
      >
        <MessageCircle className="h-6 w-6" />
      </button>
    );
  }

  return (
    <div className={`fixed bottom-6 right-6 z-50 transition-all duration-300 ${
      isMinimized ? 'w-80 h-12' : 'w-80 h-96'
    }`}>
      <div className="bg-gray-900 border border-gray-700 rounded-lg shadow-xl overflow-hidden h-full flex flex-col">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-3 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Bot className="h-5 w-5 text-white" />
            <span className="text-white font-medium">{t('chat.title')}</span>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setIsMinimized(!isMinimized)}
              className="text-white/80 hover:text-white"
              aria-label={isMinimized ? 'Expand' : 'Minimize'}
            >
              <Minimize2 className="h-4 w-4" />
            </button>
            <button
              onClick={() => setIsOpen(false)}
              className="text-white/80 hover:text-white"
              aria-label="Close chat"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {!isMinimized && (
          <>
            {/* Messages */}
            <div className="flex-1 p-3 overflow-y-auto space-y-3">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex items-start space-x-2 ${
                    message.sender === 'user' ? 'flex-row-reverse space-x-reverse' : ''
                  }`}
                >
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                    message.sender === 'ai' ? 'bg-blue-500' : 'bg-gray-600'
                  }`}>
                    {message.sender === 'ai' ? (
                      <Bot className="h-3 w-3 text-white" />
                    ) : (
                      <User className="h-3 w-3 text-white" />
                    )}
                  </div>
                  <div className={`max-w-[80%] p-2 rounded-lg text-sm ${
                    message.sender === 'ai'
                      ? 'bg-gray-800 text-gray-100'
                      : 'bg-blue-600 text-white'
                  }`}>
                    {message.text}
                  </div>
                </div>
              ))}

              {isTyping && (
                <div className="flex items-start space-x-2">
                  <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center">
                    <Bot className="h-3 w-3 text-white" />
                  </div>
                  <div className="bg-gray-800 p-2 rounded-lg">
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse"></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse delay-100"></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse delay-200"></div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Predefined Questions */}
            {messages.length === 1 && (
              <div className="px-3 pb-2">
                <p className="text-xs text-gray-400 mb-2">{t('chat.questions')}</p>
                <div className="space-y-1">
                  {predefinedQuestions.map((question, index) => (
                    <button
                      key={index}
                      onClick={() => handlePredefinedQuestion(question)}
                      className="w-full text-left text-xs text-gray-300 hover:text-blue-400 hover:bg-gray-800 p-1 rounded transition-colors"
                    >
                      {question}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Input */}
            <div className="p-3 border-t border-gray-700">
              <div className="flex space-x-2">
                <input
                  type="text"
                  value={currentMessage}
                  onChange={(e) => setCurrentMessage(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder={t('chat.placeholder')}
                  className="flex-1 bg-gray-800 border border-gray-600 rounded px-3 py-1 text-white text-sm placeholder-gray-400 focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
                <button
                  onClick={sendMessage}
                  disabled={!currentMessage.trim() || isTyping}
                  className="bg-blue-600 hover:bg-blue-700 disabled:bg-gray-700 disabled:cursor-not-allowed text-white p-1 rounded transition-colors"
                  aria-label="Send message"
                >
                  <Send className="h-4 w-4" />
                </button>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}