import { useState } from 'react';
import { MessageCircle, Send, Bot, User, X, Minimize2 } from 'lucide-react';

interface Message {
  id: number;
  text: string;
  sender: 'user' | 'ai';
  timestamp: Date;
}

export default function AIChat() {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      text: "Hello! I'm your AI fishing assistant. I can help you with builds, zone recommendations, market analysis, and answer any Albion Online fishing questions you have. What would you like to know?",
      sender: 'ai',
      timestamp: new Date()
    }
  ]);
  const [currentMessage, setCurrentMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  const predefinedQuestions = [
    "What's the best T5 fishing build?",
    "Which zones are most profitable right now?",
    "How do I avoid gankers while fishing?",
    "What food should I use for T6 fishing?"
  ];

  const sendMessage = () => {
    if (!currentMessage.trim()) return;

    const newMessage: Message = {
      id: messages.length + 1,
      text: currentMessage,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages([...messages, newMessage]);
    setCurrentMessage('');
    setIsTyping(true);

    // Simulate AI response
    setTimeout(() => {
      const aiResponse: Message = {
        id: messages.length + 2,
        text: generateAIResponse(currentMessage),
        sender: 'ai',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, aiResponse]);
      setIsTyping(false);
    }, 1500);
  };

  const generateAIResponse = (question: string) => {
    const responses: { [key: string]: string } = {
      'build': "For T5 fishing, I recommend: T5 Fishing Rod of Tenacity, Premium Grub bait, Clam Soup for +22% yield, and Major Fishing Potion. This setup costs ~200K silver but provides excellent returns in Bridgewatch or Fort Sterling zones.",
      'zone': "Currently, Martlock Elite Pools are showing the highest profit margins with T6+ fish prices up 28% this week. However, consider the increased risk. For safer profits, Bridgewatch coastal waters offer consistent T5-T6 yields with lower competition.",
      'ganker': "To avoid gankers: 1) Fish during off-peak hours, 2) Use zones with multiple escape routes, 3) Watch for red players on minimap, 4) Consider fishing in blue zones during high-activity periods, 5) Use lightweight gear in black zones.",
      'food': "For T6 fishing, Salmon Roll provides +32% fishing yield and costs ~25K silver. It's the sweet spot for T6-T7 fishing. Dragon Omelet (+44% yield) is only worth it for T7+ black zone fishing due to the 80K silver cost.",
      'default': "That's a great question! Based on current market conditions and your fishing goals, I'd recommend focusing on T5-T6 zones for the best profit-to-risk ratio. Would you like specific zone recommendations or build suggestions?"
    };

    const lowerQuestion = question.toLowerCase();

    if (lowerQuestion.includes('build')) return responses.build;
    if (lowerQuestion.includes('zone') || lowerQuestion.includes('profitable')) return responses.zone;
    if (lowerQuestion.includes('ganker') || lowerQuestion.includes('avoid') || lowerQuestion.includes('safe')) return responses.ganker;
    if (lowerQuestion.includes('food') || lowerQuestion.includes('t6')) return responses.food;

    return responses.default;
  };

  const handlePredefinedQuestion = (question: string) => {
    setCurrentMessage(question);
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 w-14 h-14 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 rounded-full shadow-lg flex items-center justify-center text-white transition-all duration-300 hover:scale-110 z-50"
      >
        <MessageCircle className="h-6 w-6" />
      </button>
    );
  }

  return (
    <div className={`fixed bottom-6 right-6 z-50 transition-all duration-300 ${
      isMinimized ? 'w-80 h-12' : 'w-80 h-96'
    }`}>
      <div className="bg-gray-900 border border-gray-700 rounded-lg shadow-xl overflow-hidden h-full flex flex-col">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-3 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Bot className="h-5 w-5 text-white" />
            <span className="text-white font-medium">AI Fishing Assistant</span>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setIsMinimized(!isMinimized)}
              className="text-white/80 hover:text-white"
            >
              <Minimize2 className="h-4 w-4" />
            </button>
            <button
              onClick={() => setIsOpen(false)}
              className="text-white/80 hover:text-white"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {!isMinimized && (
          <>
            {/* Messages */}
            <div className="flex-1 p-3 overflow-y-auto space-y-3">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex items-start space-x-2 ${
                    message.sender === 'user' ? 'flex-row-reverse space-x-reverse' : ''
                  }`}
                >
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                    message.sender === 'ai' ? 'bg-blue-500' : 'bg-gray-600'
                  }`}>
                    {message.sender === 'ai' ? (
                      <Bot className="h-3 w-3 text-white" />
                    ) : (
                      <User className="h-3 w-3 text-white" />
                    )}
                  </div>
                  <div className={`max-w-[80%] p-2 rounded-lg text-sm ${
                    message.sender === 'ai'
                      ? 'bg-gray-800 text-gray-100'
                      : 'bg-blue-600 text-white'
                  }`}>
                    {message.text}
                  </div>
                </div>
              ))}

              {isTyping && (
                <div className="flex items-start space-x-2">
                  <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center">
                    <Bot className="h-3 w-3 text-white" />
                  </div>
                  <div className="bg-gray-800 p-2 rounded-lg">
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse"></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse delay-100"></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse delay-200"></div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Predefined Questions */}
            {messages.length === 1 && (
              <div className="px-3 pb-2">
                <p className="text-xs text-gray-400 mb-2">Quick questions:</p>
                <div className="space-y-1">
                  {predefinedQuestions.map((question, index) => (
                    <button
                      key={index}
                      onClick={() => handlePredefinedQuestion(question)}
                      className="w-full text-left text-xs text-gray-300 hover:text-blue-400 hover:bg-gray-800 p-1 rounded"
                    >
                      {question}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Input */}
            <div className="p-3 border-t border-gray-700">
              <div className="flex space-x-2">
                <input
                  type="text"
                  value={currentMessage}
                  onChange={(e) => setCurrentMessage(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                  placeholder="Ask me anything about fishing..."
                  className="flex-1 bg-gray-800 border border-gray-600 rounded px-3 py-1 text-white text-sm placeholder-gray-400 focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
                <button
                  onClick={sendMessage}
                  disabled={!currentMessage.trim() || isTyping}
                  className="bg-blue-600 hover:bg-blue-700 disabled:bg-gray-700 disabled:cursor-not-allowed text-white p-1 rounded transition-colors"
                >
                  <Send className="h-4 w-4" />
                </button>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}