import { Link, useLocation } from 'react-router-dom';
import { useState } from 'react';
import { Map, Calculator, TrendingUp, Crown, Book, Settings, User, LogIn } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import LanguageSelector from './LanguageSelector';

interface NavigationProps {
  onAuthClick?: () => void;
  user?: any;
}

export default function Navigation({ onAuthClick, user }: NavigationProps) {
  const location = useLocation();
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const { t } = useLanguage();

  const navItems = [
    { path: '/', label: t('nav.dashboard'), icon: Calculator },
    { path: '/maps', label: t('nav.maps'), icon: Map },
    { path: '/tips', label: t('nav.tips'), icon: Book },
    { path: '/market', label: t('nav.market'), icon: TrendingUp },
    { path: '/premium', label: t('nav.premium'), icon: Crown },
  ];

  return (
    <nav className="bg-gray-900/90 backdrop-blur-lg border-b border-gray-800/50 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center">
            <Link to="/" className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-cyan-400 rounded-lg flex items-center justify-center">
                <Map className="h-5 w-5 text-white" />
              </div>
              <span className="text-xl font-bold text-white">AlbionFish</span>
            </Link>
          </div>

          {/* Navigation Links */}
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-4">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = location.pathname === item.path;
                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    className={`flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                      isActive
                        ? 'bg-blue-600 text-white'
                        : 'text-gray-300 hover:bg-gray-700 hover:text-white'
                    }`}
                  >
                    <Icon className="h-4 w-4 mr-2" />
                    {item.label}
                  </Link>
                );
              })}
            </div>
          </div>

          {/* Language Selector & User Menu */}
          <div className="flex items-center space-x-4">
            <LanguageSelector />
            <div className="relative">
            {user ? (
              <div className="relative">
                <button
                  onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                  className="flex items-center space-x-2 bg-gray-800 rounded-full p-2 text-gray-300 hover:text-white transition-colors"
                >
                  <User className="h-5 w-5" />
                  <span className="text-sm">{user.name}</span>
                </button>

                {isUserMenuOpen && (
                  <div className="absolute right-0 mt-2 w-48 bg-gray-800 rounded-md shadow-lg py-1 z-50">
                    <button className="flex items-center px-4 py-2 text-sm text-gray-300 hover:bg-gray-700 w-full text-left">
                      <Settings className="h-4 w-4 mr-2" />
                      {t('nav.settings')}
                    </button>
                    <button className="flex items-center px-4 py-2 text-sm text-gray-300 hover:bg-gray-700 w-full text-left">
                      <Crown className="h-4 w-4 mr-2" />
                      {t('nav.upgrade')}
                    </button>
                    <hr className="border-gray-700 my-1" />
                    <button className="flex items-center px-4 py-2 text-sm text-gray-300 hover:bg-gray-700 w-full text-left">
                      {t('nav.signout')}
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <button
                onClick={onAuthClick}
                className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-md text-white transition-colors"
              >
                <LogIn className="h-4 w-4" />
                <span>{t('nav.signin')}</span>
              </button>
            )}
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      <div className="md:hidden border-t border-gray-800">
        <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center px-3 py-2 rounded-md text-base font-medium transition-colors ${
                  isActive
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-300 hover:bg-gray-700 hover:text-white'
                }`}
              >
                <Icon className="h-5 w-5 mr-3" />
                {item.label}
              </Link>
            );
          })}
        </div>
      </div>
    </nav>
  );
}