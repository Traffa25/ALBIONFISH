import { Globe } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

export default function LanguageSelector() {
  const { language, setLanguage } = useLanguage();

  return (
    <div className="relative">
      <button
        onClick={() => setLanguage(language === 'en' ? 'es' : 'en')}
        className="flex items-center space-x-2 px-3 py-2 text-gray-300 hover:text-white transition-colors"
        title={language === 'en' ? 'Switch to Spanish' : 'Cambiar a Inglés'}
      >
        <Globe className="h-4 w-4" />
        <span className="text-sm font-medium uppercase">{language}</span>
      </button>
    </div>
  );
}