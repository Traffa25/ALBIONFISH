import { useState } from 'react';
import { Target, Zap, Shield, Utensils, Map, Star, BookOpen, Trophy } from 'lucide-react';
import Navigation from '../components/Navigation';
import AuthModal from '../components/AuthModal';

export default function Tips() {
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [user, setUser] = useState(null);
  const [activeTab, setActiveTab] = useState('builds');

  const handleLogin = (userData: any) => {
    setUser(userData);
  };

  const fishingBuilds = [
    {
      tier: 'T4',
      title: 'Beginner Fishing Setup',
      difficulty: 'Easy',
      cost: '~50K Silver',
      equipment: {
        rod: 'T4 Fishing Rod',
        bait: 'Basic Worm',
        food: 'Goose Pie',
        potion: 'Minor Fishing Potion'
      },
      stats: {
        fishingYield: '+15%',
        catchChance: '+20%',
        profitMargin: 'Low'
      },
      zones: ['Thetford River', 'Lymhurst Creek'],
      description: 'Perfect starter build for learning fishing mechanics with low investment risk.'
    },
    {
      tier: 'T5',
      title: 'Intermediate Fisher',
      difficulty: 'Medium',
      cost: '~200K Silver',
      equipment: {
        rod: 'T5 Fishing Rod of Tenacity',
        bait: 'Premium Grub',
        food: 'Clam Soup',
        potion: 'Major Fishing Potion'
      },
      stats: {
        fishingYield: '+25%',
        catchChance: '+35%',
        profitMargin: 'Medium'
      },
      zones: ['Bridgewatch Coast', 'Fort Sterling Lakes'],
      description: 'Balanced build offering good returns with manageable risk in safer zones.'
    },
    {
      tier: 'T6',
      title: 'Advanced Profit Fisher',
      difficulty: 'Hard',
      cost: '~800K Silver',
      equipment: {
        rod: 'T6 Fishing Rod of Insight',
        bait: 'Legendary Lure',
        food: 'Salmon Roll',
        potion: 'Major Fishing Potion'
      },
      stats: {
        fishingYield: '+40%',
        catchChance: '+50%',
        profitMargin: 'High'
      },
      zones: ['Martlock Elite Pools', 'Black Zone Waters'],
      description: 'High-investment build for serious fishers targeting premium catches.'
    },
    {
      tier: 'T7',
      title: 'Elite Black Zone Fisher',
      difficulty: 'Extreme',
      cost: '~2M Silver',
      equipment: {
        rod: 'T7 Fishing Rod of Excellence',
        bait: 'Mythic Bait',
        food: 'Dragon Omelet',
        potion: 'Grandmaster Fishing Potion'
      },
      stats: {
        fishingYield: '+60%',
        catchChance: '+70%',
        profitMargin: 'Extreme'
      },
      zones: ['Caerleon Blood Waters', 'Elite Black Zones'],
      description: 'Ultimate fishing setup for maximum profit in high-risk environments.'
    }
  ];

  const fishingTips = [
    {
      category: 'Equipment',
      icon: Target,
      tips: [
        'Always match your fishing rod tier to the zone you\'re fishing in for optimal results',
        'Higher tier bait significantly increases rare fish catch rates',
        'Enchanted gear provides substantial bonuses but comes with higher risk',
        'Consider backup gear when fishing in PvP zones'
      ]
    },
    {
      category: 'Food & Potions',
      icon: Utensils,
      tips: [
        'Clam Soup provides the best fishing yield bonus for the cost',
        'Dragon Omelet is worth it for T7+ fishing in black zones',
        'Stack food and potion effects for maximum efficiency',
        'Premium food pays for itself in higher-tier fishing'
      ]
    },
    {
      category: 'Zone Selection',
      icon: Map,
      tips: [
        'Fish in blue zones during peak hours for safety',
        'Black zones offer 50%+ higher profits but require PvP awareness',
        'Check city specialization bonuses before choosing fishing locations',
        'Weather effects can impact fish spawn rates in certain zones'
      ]
    },
    {
      category: 'Market Strategy',
      icon: Zap,
      tips: [
        'Track fish prices across all cities for optimal selling',
        'Weekend prices are typically 15-20% higher due to increased demand',
        'Hold rare fish during content updates for price spikes',
        'Consider processing fish into higher-value products'
      ]
    }
  ];

  const foodGuide = [
    {
      name: 'Goose Pie',
      tier: 'T3',
      bonus: '+10% Fishing Yield',
      duration: '30 minutes',
      cost: '~2K Silver',
      bestFor: 'T3-T4 Fishing'
    },
    {
      name: 'Clam Soup',
      tier: 'T5',
      bonus: '+22% Fishing Yield',
      duration: '30 minutes',
      cost: '~8K Silver',
      bestFor: 'T5-T6 Fishing'
    },
    {
      name: 'Salmon Roll',
      tier: 'T6',
      bonus: '+32% Fishing Yield',
      duration: '30 minutes',
      cost: '~25K Silver',
      bestFor: 'T6-T7 Fishing'
    },
    {
      name: 'Dragon Omelet',
      tier: 'T8',
      bonus: '+44% Fishing Yield',
      duration: '30 minutes',
      cost: '~80K Silver',
      bestFor: 'T7-T8 Black Zone'
    }
  ];

  const getTierColor = (tier: string) => {
    switch (tier) {
      case 'T4': return 'text-green-400 bg-green-500/20';
      case 'T5': return 'text-blue-400 bg-blue-500/20';
      case 'T6': return 'text-purple-400 bg-purple-500/20';
      case 'T7': return 'text-orange-400 bg-orange-500/20';
      case 'T8': return 'text-red-400 bg-red-500/20';
      default: return 'text-gray-400 bg-gray-500/20';
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Easy': return 'text-green-400';
      case 'Medium': return 'text-yellow-400';
      case 'Hard': return 'text-orange-400';
      case 'Extreme': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-900 to-blue-900">
      <Navigation onAuthClick={() => setIsAuthModalOpen(true)} user={user} />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-4">
            Fishing Tips &amp; Builds
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Master the art of fishing with expert builds, strategies, and AI-powered recommendations
          </p>
        </div>

        {/* Tab Navigation */}
        <div className="mb-8">
          <div className="flex space-x-1 bg-white/5 backdrop-blur-sm rounded-lg p-1">
            {[
              { id: 'builds', label: 'Fishing Builds', icon: Target },
              { id: 'tips', label: 'Pro Tips', icon: BookOpen },
              { id: 'food', label: 'Food Guide', icon: Utensils }
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex-1 flex items-center justify-center px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                    activeTab === tab.id
                      ? 'bg-blue-600 text-white'
                      : 'text-gray-300 hover:text-white hover:bg-white/10'
                  }`}
                >
                  <Icon className="h-4 w-4 mr-2" />
                  {tab.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Fishing Builds Tab */}
        {activeTab === 'builds' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {fishingBuilds.map((build, index) => (
              <div key={index} className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-6 hover:bg-white/10 transition-all duration-300">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <span className={`px-3 py-1 rounded-full text-sm font-bold ${getTierColor(build.tier)}`}>
                      {build.tier}
                    </span>
                    <h3 className="text-xl font-semibold text-white">{build.title}</h3>
                  </div>
                  <span className={`text-sm font-medium ${getDifficultyColor(build.difficulty)}`}>
                    {build.difficulty}
                  </span>
                </div>

                <p className="text-gray-300 text-sm mb-4">{build.description}</p>

                <div className="mb-4">
                  <h4 className="text-white font-medium mb-2 flex items-center">
                    <Shield className="h-4 w-4 mr-2" />
                    Equipment Setup
                  </h4>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Rod:</span>
                      <span className="text-white">{build.equipment.rod}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Bait:</span>
                      <span className="text-white">{build.equipment.bait}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Food:</span>
                      <span className="text-white">{build.equipment.food}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Potion:</span>
                      <span className="text-white">{build.equipment.potion}</span>
                    </div>
                  </div>
                </div>

                <div className="mb-4">
                  <h4 className="text-white font-medium mb-2 flex items-center">
                    <Star className="h-4 w-4 mr-2" />
                    Performance Stats
                  </h4>
                  <div className="grid grid-cols-3 gap-2 text-sm">
                    <div className="text-center">
                      <p className="text-gray-400">Yield</p>
                      <p className="text-green-400 font-semibold">{build.stats.fishingYield}</p>
                    </div>
                    <div className="text-center">
                      <p className="text-gray-400">Catch Rate</p>
                      <p className="text-blue-400 font-semibold">{build.stats.catchChance}</p>
                    </div>
                    <div className="text-center">
                      <p className="text-gray-400">Profit</p>
                      <p className="text-yellow-400 font-semibold">{build.stats.profitMargin}</p>
                    </div>
                  </div>
                </div>

                <div className="mb-4">
                  <h4 className="text-white font-medium mb-2">Recommended Zones</h4>
                  <div className="flex flex-wrap gap-2">
                    {build.zones.map((zone, zoneIndex) => (
                      <span key={zoneIndex} className="px-2 py-1 bg-blue-500/20 text-blue-400 text-xs rounded">
                        {zone}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-gray-400 text-sm">Total Cost: <span className="text-white font-semibold">{build.cost}</span></span>
                  <button className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-lg transition-colors">
                    Copy Build
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Pro Tips Tab */}
        {activeTab === 'tips' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {fishingTips.map((category, index) => {
              const Icon = category.icon;
              return (
                <div key={index} className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-6">
                  <h3 className="text-xl font-semibold text-white mb-4 flex items-center">
                    <Icon className="h-6 w-6 mr-2 text-blue-400" />
                    {category.category} Tips
                  </h3>
                  <div className="space-y-4">
                    {category.tips.map((tip, tipIndex) => (
                      <div key={tipIndex} className="flex items-start space-x-3">
                        <div className="w-2 h-2 bg-blue-400 rounded-full mt-2 flex-shrink-0"></div>
                        <p className="text-gray-300 text-sm leading-relaxed">{tip}</p>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Food Guide Tab */}
        {activeTab === 'food' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {foodGuide.map((food, index) => (
              <div key={index} className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-6 hover:bg-white/10 transition-all duration-300">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-lg font-semibold text-white">{food.name}</h3>
                  <span className={`px-2 py-1 rounded text-sm font-medium ${getTierColor(food.tier)}`}>
                    {food.tier}
                  </span>
                </div>

                <div className="space-y-2 mb-4">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Bonus:</span>
                    <span className="text-green-400 font-semibold">{food.bonus}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Duration:</span>
                    <span className="text-white">{food.duration}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Cost:</span>
                    <span className="text-yellow-400">{food.cost}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Best for:</span>
                    <span className="text-blue-400">{food.bestFor}</span>
                  </div>
                </div>

                <button className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-lg transition-colors">
                  View Recipe
                </button>
              </div>
            ))}
          </div>
        )}

        {/* AI Recommendations */}
        <div className="mt-12 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-xl border border-purple-500/30 p-8">
          <div className="text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-purple-500/20 rounded-full mb-4">
              <Trophy className="h-8 w-8 text-purple-400" />
            </div>
            <h3 className="text-2xl font-bold text-white mb-4">AI-Powered Recommendations</h3>
            <p className="text-gray-300 mb-6 max-w-2xl mx-auto">
              Get personalized fishing strategies based on your playstyle, budget, and goals with our advanced AI assistant
            </p>
            <button className="px-8 py-3 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-semibold rounded-xl transition-all duration-300 transform hover:scale-105">
              Get My Custom Strategy
            </button>
          </div>
        </div>
      </div>

      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onLogin={handleLogin}
      />
    </div>
  );
}