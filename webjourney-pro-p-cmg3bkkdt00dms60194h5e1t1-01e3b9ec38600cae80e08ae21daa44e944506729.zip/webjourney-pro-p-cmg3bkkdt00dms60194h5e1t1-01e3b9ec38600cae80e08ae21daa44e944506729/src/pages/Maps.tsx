import { useState, useEffect, useCallback, useMemo } from 'react';
import { MapPin, Fish, Star, Clock, Users, Zap, TrendingUp, Shield, Target, Wind, Truck, Coins, AlertTriangle, Route, Timer, Settings, Lightbulb, RefreshCw, Navigation2, Globe, Crown, Brain, CheckCircle, Edit3, Save, Calendar, BarChart3, Trophy, Lock, Download, X, BookOpen, Minimize2, Maximize2, HelpCircle, Package } from 'lucide-react';
import Navigation from '../components/Navigation';
import AuthModal from '../components/AuthModal';

interface LivePrices {
  [key: string]: number;
}

interface FishPrices {
  [key: string]: number;
}

interface MarketTrend {
  change: number;
  trend: 'rising' | 'falling' | 'stable';
  volume: number;
}

interface MarketTrends {
  [key: string]: MarketTrend;
}

interface EquipmentPrices {
  [key: string]: number;
}

interface FishingRoute {
  id: number;
  name: string;
  nameEs: string;
  zones: number[];
  totalTime: string;
  totalProfit: string;
  difficulty: string;
  description: string;
  descriptionEs: string;
  aiRecommendations: string[];
  aiRecommendationsEs: string[];
}

// Interface Translation eliminada - aplicación completamente en español

interface AdminSettings {
  goldPrice: number;
  updateInterval: number;
  volatility: 'low' | 'medium' | 'high';
  enableNotifications: boolean;
  maxConcurrentUsers: number;
  debugMode: boolean;
}

interface SeasonCalculation {
  daily: number;
  weekly: number;
  monthly: number;
  season: number;
  equipment: number;
  netProfit: number;
}

interface UserPlan {
  type: 'free' | 'premium' | 'pro';
  features: string[];
  accessLevel: number;
}

interface ImportedEquipment {
  name: string;
  price: number;
  tier: number;
  category: 'rod' | 'boots' | 'bait' | 'gear';
  lastUpdated: Date;
}


interface TutorialStep {
  id: number;
  title: string;
  content: string;
  image?: string;
  completed: boolean;
}

interface FishingGuide {
  step: number;
  title: string;
  description: string;
  equipment: string[];
  tips: string[];
  warnings: string[];
}

export default function Maps() {
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [user, setUser] = useState(null);
  const [selectedCity, setSelectedCity] = useState('all');
  const [livePrices, setLivePrices] = useState<LivePrices>({});
  const [isLoadingPrices, setIsLoadingPrices] = useState(false);
  const [lastPriceUpdate, setLastPriceUpdate] = useState<Date | null>(null);
  const [showTips, setShowTips] = useState(false);
  const [marketTrends, setMarketTrends] = useState<MarketTrends>({});
  const [language, setLanguage] = useState<'en' | 'es'>('es'); // Español por defecto
  const [goldPrice, setGoldPrice] = useState(4850);
  const [selectedRoute, setSelectedRoute] = useState<number | null>(null);
  const [showRoutes, setShowRoutes] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [showAdvancedAdmin, setShowAdvancedAdmin] = useState(false);
  const [editingPrices, setEditingPrices] = useState(false);
  const [showSeasonCalculator, setShowSeasonCalculator] = useState(false);
  const [seasonData, setSeasonData] = useState<SeasonCalculation | null>(null);
  const [importedEquipment, setImportedEquipment] = useState<ImportedEquipment[]>([]);
  const [userPlan, setUserPlan] = useState<UserPlan>({ type: 'free', features: ['basic_maps', 'basic_prices'], accessLevel: 1 });
  const [showPremiumModal, setShowPremiumModal] = useState(false);
  const [showTutorial, setShowTutorial] = useState(false);
  const [showFishingGuide, setShowFishingGuide] = useState(false);
  const [tutorialMinimized, setTutorialMinimized] = useState(false);
  const [guideMinimized, setGuideMinimized] = useState(false);
  const [currentTutorialStep, setCurrentTutorialStep] = useState(0);
  const [currentGuideStep, setCurrentGuideStep] = useState(0);
  // Estados de peso (calculados dinámicamente)
  // const [totalWeight, setTotalWeight] = useState(0);
  // const [maxCarryCapacity, setMaxCarryCapacity] = useState(100); // Base: 100kg

  // Configuraciones de administrador
  const [adminSettings, setAdminSettings] = useState<AdminSettings>({
    goldPrice: 4850,
    updateInterval: 30000,
    volatility: 'medium',
    enableNotifications: true,
    maxConcurrentUsers: 1000,
    debugMode: false
  });

  // Precios de equipos configurables (ampliado con importación)
  const [equipmentPrices, setEquipmentPrices] = useState<EquipmentPrices>({
    // Cañas de Pesca por Tier
    'Caña de Pesca Novata (T4)': 2500,
    'Caña de Pesca Adepta (T5)': 8500,
    'Caña de Pesca Experta (T6)': 25000,
    'Caña de Pesca Maestra (T7)': 85000,
    'Caña de Pesca Gran Maestra (T8)': 350000,

    // Botas por Tier
    'Sandalias de Erudito (T4)': 3200,
    'Sandalias de Clérigo (T5)': 12000,
    'Botas de Guardián (T6)': 45000,
    'Botas de Archimago (T7)': 125000,
    'Botas de Maestro (T8)': 420000,

    // Carnadas Premium
    'Gusano Básico': 60,
    'Lombriz de Tierra': 280,
    'Carne de Cangrejo': 560,
    'Carnada Real': 1200,
    'Esencia de Alma': 2400,
    'Carnada Ártica': 620,
    'Carnada Mítica': 4800,

    // Equipamiento Especializado
    'Casco de Pescador T6': 35000,
    'Armadura de Pescador T6': 45000,
    'Set Completo de Resistencia Fría': 95000,
    'Kit de Supervivencia PvP': 150000,

    // Pociones y Consumibles
    'Poción de Pesca Mayor': 1800,
    'Poción de Velocidad de Nado': 2200,
    'Comida de Pescador': 450,
    'Hidromiel de Resistencia': 680,

    // Herramientas de Guild
    'Banner de Guild': 25000,
    'Mejora de Territorio': 500000,

    // Monturas por Tier con precios actualizados
    'Caballo (T3)': 8500,
    'Armored Horse (T4)': 85000,
    'Caballo de Guerra (T5)': 450000,
    'Swift Horse (T6)': 1200000,
    'Nightmare (T7)': 4500000,
    'Sabertooth Tiger (T8)': 15000000,

    'Ox (T3)': 12000,
    'Giant Stag (T4)': 125000,
    'Direwolf (T5)': 650000,
    'Dire Bear (T6)': 1800000,
    'Mammoth (T7)': 6500000,
    'Ancient Mammoth (T8)': 22000000,

    'Mule (T3)': 6500,
    'Giant Stag Stag (T4)': 95000,
    'Direboar (T5)': 520000,
    'Swiftclaw (T6)': 1450000,
    'Direbear (T7)': 5200000,
    'Terrorbird (T8)': 18500000
  });

  // Precios base de peces configurables
  const [baseFishPrices, setBaseFishPrices] = useState<FishPrices>({
    'Freshwater Bass': 2800,
    'River Trout': 3200,
    'Carp': 2600,
    'Saltwater Cod': 4200,
    'Herring': 3800,
    'Mackerel': 4600,
    'Rare Salmon': 8900,
    'Golden Trout': 12400,
    'Ancient Carp': 15600,
    'Common Trout': 1800,
    'Perch': 1600,
    'Pike': 2200,
    'Arctic Char': 3400,
    'Ice Salmon': 4800,
    'Frost Bass': 3900,
    'Demon Fish': 18500,
    'Shadow Eel': 22000,
    'Void Carp': 28000,
    'Kraken': 45000,
    'Leviathan': 35000,
    'Giant Squid': 28000,
    'Ghost Eel': 19500,
    'Crystal Eel': 21000,
    'Bloodworm Eel': 17800,
    'Royal Shell': 8900,
    'Mystic Shell': 7200,
    'Ancient Shell': 6800,
    'Deepwater Clam': 5400,
    'Pearl Oyster': 9200,
    'Volcanic Crab': 12500,
    'Toxic Algae': 3200,
    'Seaweed Bundle': 1800,
    'Coral Fragment': 4500
  });

  // Aplicación completamente optimizada y configurada en español

  const handleLogin = (userData: any) => {
    setUser(userData);
  };


  // Tutorial steps
  const tutorialSteps: TutorialStep[] = [
    { id: 1, title: '¡Bienvenido a la Pesca en Albion!', content: 'Aprende los fundamentos de la pesca más rentable en Albion Online. Este tutorial te guiará paso a paso.', completed: false },
    { id: 2, title: 'Eligiendo tu Equipamiento', content: 'Selecciona la caña adecuada para tu nivel. Las cañas T4-T6 son ideales para principiantes, mientras que T7-T8 son para pescadores expertos.', completed: false },
    { id: 3, title: 'Navegando las Zonas', content: 'Aprende a moverte de forma segura entre zonas. Conoce las rutas principales y los puntos de escape en caso de emergencia.', completed: false },
    { id: 4, title: 'Entendiendo las Zonas', content: 'Cada zona tiene diferentes tipos de peces y niveles de riesgo. Las zonas amarillas son más seguras, las rojas más peligrosas pero más rentables.', completed: false },
    { id: 5, title: 'Calculadora de Ganancias', content: 'Usa nuestra calculadora de temporada para planificar tus ganancias y optimizar tu tiempo de pesca.', completed: false }
  ];

  // Guía de pesca paso a paso
  const fishingGuideSteps: FishingGuide[] = [
    {
      step: 1, title: 'Preparación Inicial',
      description: 'Reúne todo el equipamiento necesario antes de salir',
      equipment: ['Caña de Pesca T4+', 'Sandalias de Erudito T4+', 'Carnada apropiada', 'Comida para regeneración'],
      tips: ['Compra carnada suficiente para 2-3 horas', 'Lleva pociones de escape', 'Revisa precios de mercado actuales'],
      warnings: ['No salgas sin suficiente plata para re-equipo', 'Evita zonas rojas sin experiencia']
    },
    {
      step: 2, title: 'Selección de Zona',
      description: 'Elige la zona de pesca según tu nivel y experiencia',
      equipment: ['Mapa actualizado', 'Pociones de escape', 'Comida de regeneración'],
      tips: ['Empieza por zonas amarillas', 'Observa la actividad de jugadores', 'Ten siempre rutas de escape planificadas'],
      warnings: ['Las zonas rojas son peligrosas para principiantes', 'Evita zonas con mucha actividad PvP']
    },
    {
      step: 3, title: 'Llegando a la Zona',
      description: 'Navega de forma segura hasta tu zona objetivo',
      equipment: ['Map', 'Pociones de invisibilidad', 'Comida'],
      tips: ['Usa gates para viajes largos', 'Evita rutas populares de gankers', 'Pesca durante horarios de baja población'],
      warnings: ['Los portales pueden ser campeados', 'Nunca pesque sin checar el mapa primero']
    },
    {
      step: 4, title: 'Técnicas de Pesca',
      description: 'Maximiza tu eficiencia de pesca',
      equipment: ['Carnada premium', 'Pociones de pesca', 'Timer'],
      tips: ['Usa carnada específica para cada tipo de pez', 'Mantén el inventario organizado', 'Pesca en spots menos obvios'],
      warnings: ['No te quedes en un lugar más de 30 minutos', 'Siempre mira el minimapa']
    },
    {
      step: 5, title: 'Escape y Transporte',
      description: 'Regresa seguro con tu carga',
      equipment: ['Rutas de escape planificadas', 'Pociones de speed', 'Timing adecuado'],
      tips: ['Sal cuando tengas inventario lleno', 'Usa diferentes rutas cada vez', 'Pesca durante horas de baja actividad'],
      warnings: ['No uses las mismas rutas repetidamente', 'Los gankers campen las salidas populares']
    }
  ];

  // Función para importar precios de equipos desde API externa (simulada)
  const importEquipmentPrices = useCallback(async () => {
    setIsLoadingPrices(true);
    try {
      // Simulación de importación de precios externos
      const importedData: ImportedEquipment[] = [
        { name: 'Caña de Pesca Gran Maestra (T8)', price: 380000, tier: 8, category: 'rod', lastUpdated: new Date() },
        { name: 'Botas de Maestro (T8)', price: 450000, tier: 8, category: 'boots', lastUpdated: new Date() },
        { name: 'Carnada Mítica', price: 5200, tier: 8, category: 'bait', lastUpdated: new Date() },
        { name: 'Kit PvP Elite', price: 180000, tier: 7, category: 'gear', lastUpdated: new Date() }
      ];

      setImportedEquipment(importedData);

      // Actualizar precios existentes con datos importados
      const updatedPrices = { ...equipmentPrices };
      importedData.forEach(item => {
        updatedPrices[item.name] = item.price;
      });
      setEquipmentPrices(updatedPrices);

    } catch (error) {
      console.error('Error importing equipment prices:', error);
    } finally {
      setIsLoadingPrices(false);
    }
  }, [equipmentPrices]);

  // Sistema de planes premium
  const checkPremiumAccess = (feature: string): boolean => {
    const premiumFeatures: Record<string, boolean> = {
      'season_calculator': userPlan.accessLevel >= 2,
      'equipment_import': userPlan.accessLevel >= 2,
      'advanced_routes': userPlan.accessLevel >= 3,
      'ai_recommendations': userPlan.accessLevel >= 2,
      'price_alerts': userPlan.accessLevel >= 3,
      'guild_features': userPlan.accessLevel >= 3
    };
    return premiumFeatures[feature] || false;
  };

  const upgradeToPremium = (planType: 'premium' | 'pro') => {
    const plans = {
      premium: { type: 'premium' as const, features: ['season_calculator', 'equipment_import', 'ai_recommendations'], accessLevel: 2 },
      pro: { type: 'pro' as const, features: ['season_calculator', 'equipment_import', 'advanced_routes', 'ai_recommendations', 'price_alerts', 'guild_features'], accessLevel: 3 }
    };
    setUserPlan(plans[planType]);
    setShowPremiumModal(false);
  };


  // Sistema de precios en vivo optimizado
  const fetchLiveMarketData = useCallback(async () => {
    setIsLoadingPrices(true);
    try {
      // Volatilidad configurable
      let volatilityRange = 0.15;
      switch (adminSettings.volatility) {
        case 'low': volatilityRange = 0.05; break;
        case 'medium': volatilityRange = 0.15; break;
        case 'high': volatilityRange = 0.25; break;
      }

      const baseMultiplier = (1 - volatilityRange/2) + (Math.random() * volatilityRange);
      const timeMultiplier = 1 + (Math.sin(Date.now() / 60000) * 0.1);

      const newPrices: LivePrices = {};
      Object.keys(baseFishPrices).forEach(fishName => {
        const fishPrice = baseFishPrices[fishName];
        if (fishPrice !== undefined) {
          newPrices[fishName] = Math.floor(fishPrice * baseMultiplier * timeMultiplier);
        }
      });

      // Actualizar precio del oro
      const goldMultiplier = (1 - volatilityRange/4) + (Math.random() * volatilityRange/2);
      setGoldPrice(Math.floor(adminSettings.goldPrice * goldMultiplier));

      setLivePrices(newPrices);
      setLastPriceUpdate(new Date());

      // Calcular tendencias del mercado
      const trends: MarketTrends = {};
      Object.keys(newPrices).forEach(item => {
        const change = (Math.random() - 0.5) * 0.2;
        trends[item] = {
          change: change,
          trend: change > 0.05 ? 'rising' : change < -0.05 ? 'falling' : 'stable',
          volume: Math.floor(Math.random() * 1000) + 100
        };
      });
      setMarketTrends(trends);

    } catch (error) {
      console.error('Error al obtener datos del mercado:', error);
    } finally {
      setIsLoadingPrices(false);
    }
  }, [adminSettings, baseFishPrices]);

  // Actualización automática con intervalo configurable
  useEffect(() => {
    fetchLiveMarketData();
    const interval = setInterval(fetchLiveMarketData, adminSettings.updateInterval);
    return () => clearInterval(interval);
  }, [fetchLiveMarketData, adminSettings.updateInterval]);

  const getRecommendedConfig = useCallback((zone: any) => {
    const configs: { [key: number]: any } = {
      1: {
        gear: 'Caña de Pesca Adepta + Sandalias de Erudito',
        gearCost: equipmentPrices['Caña de Pesca Adepta'] + equipmentPrices['Sandalias de Erudito'],
        bait: 'Lombriz de Tierra',
        baitCost: equipmentPrices['Lombriz de Tierra'],
        timing: '6-8 AM durante Lluvia Ligera (+15%)',
        strategy: 'Enfócate en apariciones de peces encantados cerca del banco oriental',
        expectedProfit: '52,000-65,000 plata/hora',
        riskLevel: 'Muy Bajo - Perfecto para principiantes',
        totalInvestment: equipmentPrices['Caña de Pesca Adepta'] + equipmentPrices['Sandalias de Erudito'] + (equipmentPrices['Lombriz de Tierra'] * 100)
      },
      2: {
        gear: 'Caña de Pesca Experta + Sandalias de Clérigo',
        gearCost: equipmentPrices['Caña de Pesca Experta'] + equipmentPrices['Sandalias de Clérigo'],
        bait: 'Carne de Cangrejo',
        baitCost: equipmentPrices['Carne de Cangrejo'],
        timing: '2-4 PM cuando la competencia es menor',
        strategy: 'Apunta a bacalao T6+ cerca del puerto, usa pociones de invisibilidad',
        expectedProfit: '78,000-92,000 plata/hora',
        riskLevel: 'Bajo - Excelente relación riesgo/recompensa',
        totalInvestment: equipmentPrices['Caña de Pesca Experta'] + equipmentPrices['Sandalias de Clérigo'] + (equipmentPrices['Carne de Cangrejo'] * 50)
      },
      3: {
        gear: 'Caña de Pesca Maestra + Botas de Guardián',
        gearCost: equipmentPrices['Caña de Pesca Maestra'] + equipmentPrices['Botas de Guardián'],
        bait: 'Carnada Real',
        baitCost: equipmentPrices['Carnada Real'],
        timing: '8-10 PM durante Niebla Mística (+25% apariciones raras)',
        strategy: 'Pesca en grupos, rota estanques cada 15 minutos',
        expectedProfit: '180,000-220,000 plata/hora',
        riskLevel: 'Medio-Alto - Requiere experiencia',
        totalInvestment: equipmentPrices['Caña de Pesca Maestra'] + equipmentPrices['Botas de Guardián'] + (equipmentPrices['Carnada Real'] * 30)
      },
      4: {
        gear: 'Caña de Pesca Novata + Cualquier bota',
        gearCost: equipmentPrices['Caña de Pesca Novata'] + equipmentPrices['Cualquier bota'],
        bait: 'Gusano Básico',
        baitCost: equipmentPrices['Gusano Básico'],
        timing: '4-6 AM para la mejor experiencia de aprendizaje',
        strategy: 'Practica el lanzado cerca de troncos, aprende patrones de peces',
        expectedProfit: '32,000-38,000 plata/hora',
        riskLevel: 'Ninguno - Zona 100% segura',
        totalInvestment: equipmentPrices['Caña de Pesca Novata'] + equipmentPrices['Cualquier bota'] + (equipmentPrices['Gusano Básico'] * 200)
      },
      5: {
        gear: 'Caña de Pesca Experta + Equipo de Resistencia al Frío',
        gearCost: equipmentPrices['Caña de Pesca Experta'] + equipmentPrices['Equipo de Resistencia al Frío'],
        bait: 'Carnada Ártica',
        baitCost: equipmentPrices['Carnada Ártica'],
        timing: '10 AM-2 PM durante Ventisca (+20% peces de hielo)',
        strategy: 'Pesca cerca de respiraderos termales, evita áreas de hielo delgado',
        expectedProfit: '62,000-74,000 plata/hora',
        riskLevel: 'Bajo - Solo riesgos climáticos',
        totalInvestment: equipmentPrices['Caña de Pesca Experta'] + equipmentPrices['Equipo de Resistencia al Frío'] + (equipmentPrices['Carnada Ártica'] * 40)
      },
      6: {
        gear: 'Caña de Pesca Gran Maestra + Equipo PvP completo',
        gearCost: equipmentPrices['Caña de Pesca Gran Maestra'] + equipmentPrices['Equipo PvP completo'],
        bait: 'Esencia de Alma',
        baitCost: equipmentPrices['Esencia de Alma'],
        timing: 'Solo eventos de Luna Sangrienta (+50% todas las apariciones)',
        strategy: 'Pesca en grupos de 5+ personas, se requieren exploradores dedicados',
        expectedProfit: '350,000-450,000 plata/hora',
        riskLevel: 'Extremo - Solo jugadores PvP expertos',
        totalInvestment: equipmentPrices['Caña de Pesca Gran Maestra'] + equipmentPrices['Equipo PvP completo'] + (equipmentPrices['Esencia de Alma'] * 20)
      }
    };
    return configs[zone.id] || null;
  }, [equipmentPrices]);

  const fishingRoutes: FishingRoute[] = useMemo(() => [
    {
      id: 1,
      name: 'Beginner\'s Circuit',
      nameEs: 'Circuito de Principiantes',
      zones: [4, 1],
      totalTime: '3-4 horas',
      totalProfit: '240,000-320,000 plata',
      difficulty: 'Fácil',
      description: 'Perfect route for new players learning fishing mechanics and building initial capital',
      descriptionEs: 'Ruta perfecta para nuevos jugadores aprendiendo mecánicas de pesca y construyendo capital inicial',
      aiRecommendations: [
        'Start at Lymhurst Creek to practice casting and learn fish behavior patterns',
        'Move to Thetford Basin when comfortable with basic mechanics',
        'Use basic worms initially, upgrade to earthworms as you gain silver',
        'Focus on understanding enchantment indicators and spawn timing'
      ],
      aiRecommendationsEs: [
        'Comienza en el Arroyo de Lymhurst para practicar el lanzado y aprender patrones de comportamiento de peces',
        'Muévete a la Cuenca de Thetford cuando te sientas cómodo con las mecánicas básicas',
        'Usa gusanos básicos inicialmente, mejora a lombrices de tierra cuando ganes plata',
        'Enfócate en entender indicadores de encantamiento y tiempo de aparición'
      ]
    },
    {
      id: 2,
      name: 'Coastal Profit Run',
      nameEs: 'Ruta de Ganancias Costeras',
      zones: [2, 5],
      totalTime: '4-5 horas',
      totalProfit: '480,000-640,000 plata',
      difficulty: 'Medio',
      description: 'High-yield coastal route focusing on premium saltwater species',
      descriptionEs: 'Ruta costera de alto rendimiento enfocada en especies de agua salada premium',
      aiRecommendations: [
        'Begin at Bridgewatch during low competition hours (2-4 PM)',
        'Use crab meat bait for maximum squid spawn chances',
        'Travel to Fort Sterling during blizzard weather for ice fish bonuses',
        'Carry invisibility potions for emergency escapes from gankers'
      ],
      aiRecommendationsEs: [
        'Comienza en Bridgewatch durante horas de baja competencia (2-4 PM)',
        'Usa carnada de carne de cangrejo para máximas posibilidades de aparición de calamares',
        'Viaja a Fort Sterling durante clima de ventisca para bonos de peces de hielo',
        'Lleva pociones de invisibilidad para escapes de emergencia de atacantes'
      ]
    },
    {
      id: 3,
      name: 'Elite Challenge Route',
      nameEs: 'Ruta del Desafío Elite',
      zones: [3, 6],
      totalTime: '6-8 horas',
      totalProfit: '1,200,000-1,800,000 plata',
      difficulty: 'Extremo',
      description: 'High-risk, high-reward route for experienced players seeking maximum profits',
      descriptionEs: 'Ruta de alto riesgo y alta recompensa para jugadores experimentados que buscan ganancias máximas',
      aiRecommendations: [
        'Only attempt with T7+ gear and 20M+ silver insurance',
        'Fish Martlock pools during mystical fog events (8-10 PM)',
        'Enter Caerleon only during Blood Moon with 5+ experienced team members',
        'Use royal bait and soul essence for legendary fish spawns',
        'Have escape plan and emergency silver for regearing'
      ],
      aiRecommendationsEs: [
        'Solo intenta con equipo T7+ y seguro de 20M+ plata',
        'Pesca en las pozas de Martlock durante eventos de niebla mística (8-10 PM)',
        'Entra a Caerleon solo durante Luna Sangrienta con 5+ miembros de equipo experimentados',
        'Usa carnada real y esencia de alma para apariciones de peces legendarios',
        'Ten plan de escape y plata de emergencia para re-equiparse'
      ]
    },
    {
      id: 4,
      name: 'Balanced Progression',
      nameEs: 'Progresión Equilibrada',
      zones: [1, 2, 3],
      totalTime: '5-6 horas',
      totalProfit: '680,000-920,000 plata',
      difficulty: 'Medio-Difícil',
      description: 'Progressive difficulty route building skills and capital simultaneously',
      descriptionEs: 'Ruta de dificultad progresiva construyendo habilidades y capital simultáneamente',
      aiRecommendations: [
        'Start at Thetford during rain events for bonus catch rates',
        'Progress to Bridgewatch when you have 100K+ silver for better bait',
        'End at Martlock elite pools if you\'re confident in your skills',
        'Each zone teaches different mechanics: timing, bait selection, risk management'
      ],
      aiRecommendationsEs: [
        'Comienza en Thetford durante eventos de lluvia para tasas de captura bonus',
        'Progresa a Bridgewatch cuando tengas 100K+ plata para mejor carnada',
        'Termina en las pozas elite de Martlock si confías en tus habilidades',
        'Cada zona enseña diferentes mecánicas: tiempo, selección de carnada, gestión de riesgos'
      ]
    }
  ], []);

  const cities = useMemo(() => [
    {
      id: 'thetford',
      name: 'Thetford',
      zones: 12,
      quality: 4.8,
      difficulty: 'Fácil',
      bestTime: '6-10 AM',
      population: 'Alta',
      color: 'green',
      description: 'Zonas de pesca ricas con capturas consistentes'
    },
    {
      id: 'bridgewatch',
      name: 'Bridgewatch',
      zones: 15,
      quality: 4.6,
      difficulty: 'Medio',
      bestTime: '2-6 PM',
      population: 'Media',
      color: 'blue',
      description: 'Especies de peces diversas y buenos márgenes de ganancia'
    },
    {
      id: 'martlock',
      name: 'Martlock',
      zones: 10,
      quality: 4.9,
      difficulty: 'Difícil',
      bestTime: '8-12 PM',
      population: 'Baja',
      color: 'purple',
      description: 'Spots de pesca premium con capturas raras'
    },
    {
      id: 'lymhurst',
      name: 'Lymhurst',
      zones: 13,
      quality: 4.7,
      difficulty: 'Fácil',
      bestTime: '4-8 AM',
      population: 'Alta',
      color: 'yellow',
      description: 'Aguas amigables para principiantes con ingresos estables'
    },
    {
      id: 'fortsterling',
      name: 'Fort Sterling',
      zones: 11,
      quality: 4.5,
      difficulty: 'Medio',
      bestTime: '10-2 PM',
      population: 'Media',
      color: 'cyan',
      description: 'Experiencia de pesca equilibrada con buena variedad'
    },
    {
      id: 'caerleon',
      name: 'Caerleon',
      zones: 8,
      quality: 5.0,
      difficulty: 'Extremo',
      bestTime: 'Todo el Día',
      population: 'Muy Alta',
      color: 'red',
      description: 'Pesca de zona negra de alto riesgo y alta recompensa'
    }
  ], []);

  const fishingZones = useMemo(() => [
    {
      id: 1,
      name: 'Cuenca del Río Thetford',
      city: 'thetford',
      tier: 'T4-T6',
      fish: [
        { name: 'Freshwater Bass', basePrice: baseFishPrices['Freshwater Bass'], enchant: '.1-.3' },
        { name: 'River Trout', basePrice: baseFishPrices['River Trout'], enchant: '.2-.4' },
        { name: 'Carp', basePrice: baseFishPrices['Carp'], enchant: '.1-.2' },
        { name: 'Seaweed Bundle', basePrice: baseFishPrices['Seaweed Bundle'], enchant: '.0-.2' },
        { name: 'Toxic Algae', basePrice: baseFishPrices['Toxic Algae'], enchant: '.1-.3' }
      ],
      danger: 'Seguro',
      profit: 'Alto',
      coordinates: 'X: 1245, Y: 890',
      resources: ['Fibra', 'Madera'],
      description: 'Ubicación de agua dulce principal con capturas consistentes T5+',
      marketData: {
        avgProfit: '48,000 plata/hora',
        marketTrend: 'estable',
        competition: 'Media',
        transportCost: 450
      },
      baitRecommendations: [
        { bait: 'Gusano', effectiveness: 'Alto', cost: 120 },
        { bait: 'Lombriz de Tierra', effectiveness: 'Muy Alto', cost: 280 },
        { bait: 'Larva', effectiveness: 'Medio', cost: 80 }
      ],
      pvpRisk: {
        level: 'Muy Bajo',
        escapeRoutes: ['Puente Norte', 'Portal Este', 'Sendero Sur'],
        gankerFrequency: '2-3/día',
        safetyTips: 'Usa montura para escape rápido, pesca cerca de las salidas'
      },
      weatherEffects: {
        current: 'Lluvia Ligera',
        bonus: '+15% tasa de captura',
        nextChange: '2h 15m'
      },
      spawnRates: {
        normal: '65%',
        enchanted: '30%',
        rare: '5%'
      }
    },
    {
      id: 2,
      name: 'Aguas Costeras de Bridgewatch',
      city: 'bridgewatch',
      tier: 'T5-T7',
      fish: [
        { name: 'Saltwater Cod', basePrice: baseFishPrices['Saltwater Cod'], enchant: '.2-.4' },
        { name: 'Herring', basePrice: baseFishPrices['Herring'], enchant: '.1-.3' },
        { name: 'Mackerel', basePrice: baseFishPrices['Mackerel'], enchant: '.3-.4' },
        { name: 'Giant Squid', basePrice: baseFishPrices['Giant Squid'], enchant: '.3-.4' },
        { name: 'Royal Shell', basePrice: baseFishPrices['Royal Shell'], enchant: '.2-.3' }
      ],
      danger: 'Bajo',
      profit: 'Muy Alto',
      coordinates: 'X: 2156, Y: 1234',
      resources: ['Piedra', 'Mineral'],
      description: 'Pesca costera con excelentes rendimientos T6+',
      marketData: {
        avgProfit: '72,000 plata/hora',
        marketTrend: 'subiendo',
        competition: 'Baja',
        transportCost: 320
      },
      baitRecommendations: [
        { bait: 'Camarón', effectiveness: 'Muy Alto', cost: 380 },
        { bait: 'Gusano de Agua Salada', effectiveness: 'Alto', cost: 220 },
        { bait: 'Carne de Cangrejo', effectiveness: 'Extremo', cost: 560 }
      ],
      pvpRisk: {
        level: 'Bajo',
        escapeRoutes: ['Salida del Puerto', 'Sendero del Acantilado', 'Túnel Subterráneo'],
        gankerFrequency: '4-5/día',
        safetyTips: 'Mantente cerca de los acantilados, usa pociones de invisibilidad'
      },
      weatherEffects: {
        current: 'Soleado',
        bonus: 'Tasas normales',
        nextChange: '45m'
      },
      spawnRates: {
        normal: '55%',
        enchanted: '35%',
        rare: '10%'
      }
    },
    {
      id: 3,
      name: 'Pozas Elite de Martlock',
      city: 'martlock',
      tier: 'T6-T8',
      fish: [
        { name: 'Rare Salmon', basePrice: baseFishPrices['Rare Salmon'], enchant: '.3-.4' },
        { name: 'Golden Trout', basePrice: baseFishPrices['Golden Trout'], enchant: '.2-.4' },
        { name: 'Ancient Carp', basePrice: baseFishPrices['Ancient Carp'], enchant: '.4' },
        { name: 'Crystal Eel', basePrice: baseFishPrices['Crystal Eel'], enchant: '.3-.4' },
        { name: 'Mystic Shell', basePrice: baseFishPrices['Mystic Shell'], enchant: '.2-.3' }
      ],
      danger: 'Medio',
      profit: 'Extremo',
      coordinates: 'X: 890, Y: 1567',
      resources: ['Piedra Rara', 'Cristal'],
      description: 'Pozas exclusivas con apariciones de peces legendarios',
      marketData: {
        avgProfit: '156,000 plata/hora',
        marketTrend: 'volátil',
        competition: 'Muy Alta',
        transportCost: 890
      },
      baitRecommendations: [
        { bait: 'Mosca Premium', effectiveness: 'Extremo', cost: 750 },
        { bait: 'Carnada Real', effectiveness: 'Legendario', cost: 1200 },
        { bait: 'Gusano de Cristal', effectiveness: 'Muy Alto', cost: 480 }
      ],
      pvpRisk: {
        level: 'Medio-Alto',
        escapeRoutes: ['Cueva Oculta', 'Puente del Árbol', 'Paso de Montaña'],
        gankerFrequency: '8-12/día',
        safetyTips: 'Pesca en grupos, lleva equipo de escape, evita horas pico'
      },
      weatherEffects: {
        current: 'Niebla Mística',
        bonus: '+25% tasa de aparición rara',
        nextChange: '1h 30m'
      },
      spawnRates: {
        normal: '40%',
        enchanted: '45%',
        rare: '15%'
      }
    },
    {
      id: 4,
      name: 'Arroyo Inicial de Lymhurst',
      city: 'lymhurst',
      tier: 'T3-T5',
      fish: [
        { name: 'Common Trout', basePrice: baseFishPrices['Common Trout'], enchant: '.0-.2' },
        { name: 'Perch', basePrice: baseFishPrices['Perch'], enchant: '.1-.2' },
        { name: 'Pike', basePrice: baseFishPrices['Pike'], enchant: '.1-.3' },
        { name: 'Ancient Shell', basePrice: baseFishPrices['Ancient Shell'], enchant: '.1-.2' },
        { name: 'Coral Fragment', basePrice: baseFishPrices['Coral Fragment'], enchant: '.1-.2' }
      ],
      danger: 'Seguro',
      profit: 'Medio',
      coordinates: 'X: 1678, Y: 567',
      resources: ['Cuero', 'Fibra'],
      description: 'Perfecto para principiantes aprendiendo mecánicas de pesca',
      marketData: {
        avgProfit: '28,000 plata/hora',
        marketTrend: 'estable',
        competition: 'Alta',
        transportCost: 180
      },
      baitRecommendations: [
        { bait: 'Gusano Básico', effectiveness: 'Medio', cost: 60 },
        { bait: 'Escarabajo', effectiveness: 'Alto', cost: 90 },
        { bait: 'Larva', effectiveness: 'Medio', cost: 45 }
      ],
      pvpRisk: {
        level: 'Ninguno',
        escapeRoutes: ['Múltiples salidas seguras'],
        gankerFrequency: '0/día',
        safetyTips: 'Zona completamente segura - perfecta para aprender'
      },
      weatherEffects: {
        current: 'Nublado',
        bonus: '+5% tasa de captura',
        nextChange: '3h 20m'
      },
      spawnRates: {
        normal: '80%',
        enchanted: '18%',
        rare: '2%'
      }
    },
    {
      id: 5,
      name: 'Lagos Helados de Fort Sterling',
      city: 'fortsterling',
      tier: 'T4-T6',
      fish: [
        { name: 'Arctic Char', basePrice: baseFishPrices['Arctic Char'], enchant: '.2-.3' },
        { name: 'Ice Salmon', basePrice: baseFishPrices['Ice Salmon'], enchant: '.2-.4' },
        { name: 'Frost Bass', basePrice: baseFishPrices['Frost Bass'], enchant: '.1-.3' },
        { name: 'Pearl Oyster', basePrice: baseFishPrices['Pearl Oyster'], enchant: '.2-.4' },
        { name: 'Deepwater Clam', basePrice: baseFishPrices['Deepwater Clam'], enchant: '.1-.3' }
      ],
      danger: 'Bajo',
      profit: 'Alto',
      coordinates: 'X: 345, Y: 1890',
      resources: ['Hielo', 'Cristal'],
      description: 'Especies únicas de agua fría con propiedades especiales',
      marketData: {
        avgProfit: '54,000 plata/hora',
        marketTrend: 'subiendo',
        competition: 'Media',
        transportCost: 280
      },
      baitRecommendations: [
        { bait: 'Gusano Congelado', effectiveness: 'Muy Alto', cost: 340 },
        { bait: 'Larva de Hielo', effectiveness: 'Alto', cost: 180 },
        { bait: 'Carnada Ártica', effectiveness: 'Extremo', cost: 620 }
      ],
      pvpRisk: {
        level: 'Bajo',
        escapeRoutes: ['Puente de Hielo', 'Túnel Congelado', 'Cueva de Cristal'],
        gankerFrequency: '3-4/día',
        safetyTips: 'Usa equipo de resistencia al frío, mantente en senderos principales'
      },
      weatherEffects: {
        current: 'Ventisca',
        bonus: '+20% tasa de aparición de peces de hielo',
        nextChange: '55m'
      },
      spawnRates: {
        normal: '60%',
        enchanted: '32%',
        rare: '8%'
      }
    },
    {
      id: 6,
      name: 'Aguas Sangrientas de Caerleon',
      city: 'caerleon',
      tier: 'T7-T8',
      fish: [
        { name: 'Demon Fish', basePrice: baseFishPrices['Demon Fish'], enchant: '.3-.4' },
        { name: 'Shadow Eel', basePrice: baseFishPrices['Shadow Eel'], enchant: '.4' },
        { name: 'Void Carp', basePrice: baseFishPrices['Void Carp'], enchant: '.4' },
        { name: 'Kraken', basePrice: baseFishPrices['Kraken'], enchant: '.4' },
        { name: 'Leviathan', basePrice: baseFishPrices['Leviathan'], enchant: '.4' },
        { name: 'Ghost Eel', basePrice: baseFishPrices['Ghost Eel'], enchant: '.3-.4' },
        { name: 'Bloodworm Eel', basePrice: baseFishPrices['Bloodworm Eel'], enchant: '.3-.4' },
        { name: 'Volcanic Crab', basePrice: baseFishPrices['Volcanic Crab'], enchant: '.2-.4' }
      ],
      danger: 'Extremo',
      profit: 'Legendario',
      coordinates: 'X: 2345, Y: 2156',
      resources: ['Almas', 'Materia Oscura'],
      description: 'Pesca de zona negra con capturas de otro mundo',
      marketData: {
        avgProfit: '280,000 plata/hora',
        marketTrend: 'altamente volátil',
        competition: 'Extrema',
        transportCost: 1500
      },
      baitRecommendations: [
        { bait: 'Esencia de Alma', effectiveness: 'Legendario', cost: 2400 },
        { bait: 'Gusano del Vacío', effectiveness: 'Extremo', cost: 1800 },
        { bait: 'Larva de Sangre', effectiveness: 'Muy Alto', cost: 950 }
      ],
      pvpRisk: {
        level: 'Extremo',
        escapeRoutes: ['Red de Portales', 'Pasajes Subterráneos', 'Portales de Sombra'],
        gankerFrequency: '20+/día',
        safetyTips: 'Equipo PvP completo obligatorio, pesca en grupos grandes, usa exploradores'
      },
      weatherEffects: {
        current: 'Luna Sangrienta',
        bonus: '+50% todas las tasas de aparición, +30% oportunidad de encantamiento',
        nextChange: '20m'
      },
      spawnRates: {
        normal: '25%',
        enchanted: '50%',
        rare: '25%'
      }
    }
  ], [baseFishPrices]);

  // Función para calcular ganancias por temporada
  const calculateSeasonProfits = useCallback((zoneId: number, hoursPerDay: number = 4) => {
    const zone = fishingZones.find(z => z.id === zoneId);
    if (!zone) return null;

    // Calcular ganancia promedio por hora basada en los peces de la zona
    let avgHourlyProfit = 0;
    zone.fish.forEach(fish => {
      const currentPrice = livePrices[fish.name] || fish.basePrice;
      const fishPerHour = 15; // Estimación promedio
      avgHourlyProfit += (currentPrice * fishPerHour) / zone.fish.length;
    });

    // Calcular costos de equipamiento
    const equipmentCost = equipmentPrices['Caña de Pesca Experta (T6)'] +
                         equipmentPrices['Botas de Guardián (T6)'] +
                         equipmentPrices['Carnada Real'] * 100; // 100 unidades de carnada

    const daily = avgHourlyProfit * hoursPerDay;
    const weekly = daily * 7;
    const monthly = daily * 30;
    const season = daily * 90; // Una temporada = 3 meses
    const netProfit = season - equipmentCost;

    return {
      daily,
      weekly,
      monthly,
      season,
      equipment: equipmentCost,
      netProfit
    };
  }, [fishingZones, livePrices, equipmentPrices]);

  // Optimización: filtros memoizados
  const filteredZones = useMemo(() => {
    return selectedCity === 'all'
      ? fishingZones
      : fishingZones.filter(zone => zone.city === selectedCity);
  }, [selectedCity, fishingZones]);

  const getDangerColor = useCallback((danger: string) => {
    switch (danger) {
      case 'Seguro': return 'text-green-400 bg-green-500/20';
      case 'Bajo': return 'text-yellow-400 bg-yellow-500/20';
      case 'Medio': return 'text-orange-400 bg-orange-500/20';
      case 'Medio-Alto': return 'text-orange-400 bg-orange-500/20';
      case 'Extremo': return 'text-red-400 bg-red-500/20';
      case 'Muy Bajo': return 'text-green-400 bg-green-500/20';
      case 'Ninguno': return 'text-green-400 bg-green-500/20';
      default: return 'text-gray-400 bg-gray-500/20';
    }
  }, []);

  const getProfitColor = useCallback((profit: string) => {
    switch (profit) {
      case 'Medio': return 'text-yellow-400';
      case 'Alto': return 'text-green-400';
      case 'Muy Alto': return 'text-cyan-400';
      case 'Extremo': return 'text-purple-400';
      case 'Legendario': return 'text-orange-400';
      default: return 'text-gray-400';
    }
  }, []);

  const getRouteColor = useCallback((difficulty: string) => {
    switch (difficulty) {
      case 'Fácil': return 'border-green-500/30 bg-green-500/10';
      case 'Medio': return 'border-yellow-500/30 bg-yellow-500/10';
      case 'Medio-Difícil': return 'border-orange-500/30 bg-orange-500/10';
      case 'Difícil': return 'border-red-500/30 bg-red-500/10';
      case 'Extremo': return 'border-purple-500/30 bg-purple-500/10';
      default: return 'border-gray-500/30 bg-gray-500/10';
    }
  }, []);

  // Funciones para manejo de precios
  const updateEquipmentPrice = (item: string, price: number) => {
    setEquipmentPrices(prev => ({
      ...prev,
      [item]: price
    }));
  };

  const updateFishPrice = (fish: string, price: number) => {
    setBaseFishPrices(prev => ({
      ...prev,
      [fish]: price
    }));
  };

  const saveAdminSettings = () => {
    // Aquí se guardarían las configuraciones en el backend
    console.log('Configuraciones guardadas:', adminSettings);
    alert('Configuraciones guardadas exitosamente');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-900 to-blue-900">
      <Navigation onAuthClick={() => setIsAuthModalOpen(true)} user={user} />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Encabezado con Estado del Mercado en Vivo */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-4">
            <h1 className="text-4xl md:text-6xl font-bold text-white mr-4">
              Mapas y Zonas de Pesca
            </h1>
            <div className="flex items-center space-x-3">
              <button
                onClick={() => setLanguage(language === 'en' ? 'es' : 'en')}
                className="flex items-center px-3 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-colors"
              >
                <Globe className="h-4 w-4 mr-2" />
                {language === 'en' ? 'ES' : 'EN'}
              </button>
              <button
                onClick={fetchLiveMarketData}
                disabled={isLoadingPrices}
                className="flex items-center px-3 py-2 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white rounded-lg transition-colors"
              >
                <RefreshCw className={`h-4 w-4 mr-2 ${isLoadingPrices ? 'animate-spin' : ''}`} />
                {isLoadingPrices ? 'Actualizando...' : 'Actualizar Precios'}
              </button>
              {user && (
                <button
                  onClick={() => setIsAdmin(!isAdmin)}
                  className="flex items-center px-3 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors"
                >
                  <Crown className="h-4 w-4 mr-2" />
                  Panel de Administrador
                </button>
              )}
              <div className="text-xs text-gray-400">
                {lastPriceUpdate && (
                  <>Última actualización: {lastPriceUpdate.toLocaleTimeString()}</>
                )}
              </div>
            </div>
          </div>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Explora ubicaciones de pesca detalladas con <span className="text-green-400 font-semibold">precios de mercado en vivo</span> y recomendaciones impulsadas por IA
          </p>
          <div className="flex items-center justify-center mt-4 space-x-4">
            <div className="flex items-center text-green-400">
              <div className="w-2 h-2 bg-green-400 rounded-full mr-2 animate-pulse"></div>
              Datos de Mercado en Vivo Activos
            </div>
            <div className="text-gray-400">|</div>
            <div className="text-blue-400">
              {Object.keys(livePrices).length} artículos rastreados
            </div>
            <div className="text-gray-400">|</div>
            <div className="text-yellow-400">
              💰 Oro: {goldPrice.toLocaleString()} plata
            </div>
          </div>
        </div>

        {/* Sección del Mercado de Oro */}
        <div className="mb-8 bg-gradient-to-r from-yellow-500/10 to-orange-500/10 rounded-xl border border-yellow-500/20 p-6">
          <h2 className="text-2xl font-bold text-white mb-4 flex items-center">
            <Coins className="h-6 w-6 mr-2 text-yellow-400" />
            Mercado de Intercambio de Oro
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-yellow-400">{goldPrice.toLocaleString()}</div>
              <div className="text-gray-400">Plata por Oro</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-400">
                {Math.floor(1000000 / goldPrice).toLocaleString()}
              </div>
              <div className="text-gray-400">Oro por 1M Plata</div>
            </div>
            <div className="text-center">
              <div className="text-xl font-medium text-gray-400">
                Tendencia: Estable
                <span className="ml-2">
                  {Math.random() > 0.5 ? '↗' : Math.random() > 0.25 ? '↘' : '→'}
                </span>
              </div>
              <div className="text-xs text-gray-500 mt-1">
                Actualizado cada {adminSettings.updateInterval / 1000}s
              </div>
            </div>
          </div>
        </div>

        {/* Panel de Configuración de Administrador Avanzado */}
        {isAdmin && user && (
          <div className="mb-8 bg-red-500/10 border border-red-500/20 rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl font-bold text-white flex items-center">
                <Crown className="h-6 w-6 mr-2 text-red-400" />
                Panel de Configuración de Administrador
              </h2>
              <button
                onClick={() => setShowAdvancedAdmin(!showAdvancedAdmin)}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
              >
                {showAdvancedAdmin ? 'Ocultar Avanzado' : 'Mostrar Avanzado'}
              </button>
            </div>

            {/* Configuraciones Básicas */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              <div>
                <label className="block text-white text-sm font-medium mb-2">
                  Precio del Oro
                </label>
                <input
                  type="number"
                  value={adminSettings.goldPrice}
                  onChange={(e) => setAdminSettings(prev => ({
                    ...prev,
                    goldPrice: parseInt(e.target.value) || 4850
                  }))}
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white"
                />
              </div>
              <div>
                <label className="block text-white text-sm font-medium mb-2">
                  Frecuencia de Actualización
                </label>
                <select
                  value={adminSettings.updateInterval}
                  onChange={(e) => setAdminSettings(prev => ({
                    ...prev,
                    updateInterval: parseInt(e.target.value)
                  }))}
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white"
                >
                  <option value="10000">10 segundos</option>
                  <option value="30000">30 segundos</option>
                  <option value="60000">1 minuto</option>
                  <option value="300000">5 minutos</option>
                </select>
              </div>
              <div>
                <label className="block text-white text-sm font-medium mb-2">
                  Volatilidad del Mercado
                </label>
                <select
                  value={adminSettings.volatility}
                  onChange={(e) => setAdminSettings(prev => ({
                    ...prev,
                    volatility: e.target.value as 'low' | 'medium' | 'high'
                  }))}
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white"
                >
                  <option value="low">Baja (±5%)</option>
                  <option value="medium">Media (±15%)</option>
                  <option value="high">Alta (±25%)</option>
                </select>
              </div>
            </div>

            {/* Configuraciones Avanzadas */}
            {showAdvancedAdmin && (
              <div className="space-y-6">
                {/* Editor de Precios de Equipos */}
                <div className="bg-gray-800/30 rounded-lg p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-xl font-bold text-white">Precios de Equipos</h3>
                    <button
                      onClick={() => setEditingPrices(!editingPrices)}
                      className="flex items-center px-3 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors"
                    >
                      <Edit3 className="h-4 w-4 mr-2" />
                      {editingPrices ? 'Terminar Edición' : 'Editar Precios'}
                    </button>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {Object.entries(equipmentPrices).map(([item, price]) => (
                      <div key={item} className="flex items-center justify-between bg-gray-700/50 p-3 rounded">
                        <span className="text-gray-300 text-sm">{item}</span>
                        {editingPrices ? (
                          <input
                            type="number"
                            value={price}
                            onChange={(e) => updateEquipmentPrice(item, parseInt(e.target.value) || 0)}
                            className="w-20 bg-gray-800 border border-gray-600 rounded px-2 py-1 text-white text-sm"
                          />
                        ) : (
                          <span className="text-yellow-400 font-medium">{price.toLocaleString()}</span>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Editor de Precios Base de Peces */}
                <div className="bg-gray-800/30 rounded-lg p-6">
                  <h3 className="text-xl font-bold text-white mb-4">Precios Base de Peces</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    {Object.entries(baseFishPrices).map(([fish, price]) => (
                      <div key={fish} className="flex items-center justify-between bg-gray-700/50 p-3 rounded">
                        <span className="text-gray-300 text-sm">{fish}</span>
                        {editingPrices ? (
                          <input
                            type="number"
                            value={price}
                            onChange={(e) => updateFishPrice(fish, parseInt(e.target.value) || 0)}
                            className="w-20 bg-gray-800 border border-gray-600 rounded px-2 py-1 text-white text-sm"
                          />
                        ) : (
                          <span className="text-blue-400 font-medium">{price.toLocaleString()}</span>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Configuraciones del Sistema */}
                <div className="bg-gray-800/30 rounded-lg p-6">
                  <h3 className="text-xl font-bold text-white mb-4">Configuraciones del Sistema</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-300">Habilitar Notificaciones</span>
                      <input
                        type="checkbox"
                        checked={adminSettings.enableNotifications}
                        onChange={(e) => setAdminSettings(prev => ({
                          ...prev,
                          enableNotifications: e.target.checked
                        }))}
                        className="w-5 h-5"
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-300">Modo Debug</span>
                      <input
                        type="checkbox"
                        checked={adminSettings.debugMode}
                        onChange={(e) => setAdminSettings(prev => ({
                          ...prev,
                          debugMode: e.target.checked
                        }))}
                        className="w-5 h-5"
                      />
                    </div>
                    <div>
                      <label className="block text-gray-300 text-sm mb-2">
                        Máximo de Usuarios
                      </label>
                      <input
                        type="number"
                        value={adminSettings.maxConcurrentUsers}
                        onChange={(e) => setAdminSettings(prev => ({
                          ...prev,
                          maxConcurrentUsers: parseInt(e.target.value) || 1000
                        }))}
                        className="w-full bg-gray-800 border border-gray-700 rounded px-3 py-2 text-white"
                      />
                    </div>
                  </div>
                </div>

                <button
                  onClick={saveAdminSettings}
                  className="w-full flex items-center justify-center px-6 py-3 bg-green-600 hover:bg-green-700 text-white font-medium rounded-lg transition-colors"
                >
                  <Save className="h-5 w-5 mr-2" />
                  Guardar Todas las Configuraciones
                </button>
              </div>
            )}
          </div>
        )}

        {/* Vista General de Ciudades */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-white mb-6">Vista General de Ciudades</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {cities.map((city) => (
              <div key={city.id} className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-6 hover:bg-white/10 transition-all duration-300 cursor-pointer"
                   onClick={() => setSelectedCity(city.id)}>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xl font-semibold text-white">{city.name}</h3>
                  <div className={`flex items-center text-${city.color}-400`}>
                    <Star className="h-4 w-4 mr-1" />
                    <span>{city.quality}</span>
                  </div>
                </div>
                <p className="text-gray-300 text-sm mb-4">{city.description}</p>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="flex items-center text-gray-400">
                    <MapPin className="h-4 w-4 mr-2" />
                    {city.zones} zonas
                  </div>
                  <div className="flex items-center text-gray-400">
                    <Clock className="h-4 w-4 mr-2" />
                    {city.bestTime}
                  </div>
                  <div className="flex items-center text-gray-400">
                    <Zap className="h-4 w-4 mr-2" />
                    {city.difficulty}
                  </div>
                  <div className="flex items-center text-gray-400">
                    <Users className="h-4 w-4 mr-2" />
                    {city.population}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>


        {/* Controles de Filtro, Consejos y Rutas */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-white">Zonas de Pesca</h2>
            <div className="flex items-center space-x-4">
              <button
                onClick={() => setShowRoutes(!showRoutes)}
                className={`flex items-center px-4 py-2 rounded-lg transition-colors ${
                  showRoutes ? 'bg-cyan-600 hover:bg-cyan-700' : 'bg-gray-600 hover:bg-gray-700'
                } text-white`}
              >
                <Navigation2 className="h-4 w-4 mr-2" />
                {showRoutes ? 'Ocultar Rutas' : 'Mostrar Rutas'}
              </button>
              <button
                onClick={() => setShowTips(!showTips)}
                className={`flex items-center px-4 py-2 rounded-lg transition-colors ${
                  showTips ? 'bg-green-600 hover:bg-green-700' : 'bg-gray-600 hover:bg-gray-700'
                } text-white`}
              >
                <Lightbulb className="h-4 w-4 mr-2" />
                {showTips ? 'Ocultar Consejos' : 'Mostrar Consejos'}
              </button>
              <button
                onClick={() => checkPremiumAccess('season_calculator') ? setShowSeasonCalculator(!showSeasonCalculator) : setShowPremiumModal(true)}
                className={`flex items-center px-4 py-2 rounded-lg transition-colors ${
                  showSeasonCalculator ? 'bg-amber-600 hover:bg-amber-700' : 'bg-gray-600 hover:bg-gray-700'
                } text-white relative`}
              >
                <Calendar className="h-4 w-4 mr-2" />
                Calculadora de Temporada
                {!checkPremiumAccess('season_calculator') && (
                  <Lock className="h-3 w-3 ml-1 text-yellow-400" />
                )}
              </button>
              <button
                onClick={() => checkPremiumAccess('equipment_import') ? importEquipmentPrices() : setShowPremiumModal(true)}
                className="flex items-center px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-colors relative"
                disabled={isLoadingPrices}
              >
                {isLoadingPrices ? (
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <Download className="h-4 w-4 mr-2" />
                )}
                Importar Equipos
                {!checkPremiumAccess('equipment_import') && (
                  <Lock className="h-3 w-3 ml-1 text-yellow-400" />
                )}
              </button>
              <button
                onClick={() => setShowTutorial(true)}
                className="flex items-center px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors"
              >
                <BookOpen className="h-4 w-4 mr-2" />
                Tutorial
              </button>
              <button
                onClick={() => setShowFishingGuide(true)}
                className="flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
              >
                <HelpCircle className="h-4 w-4 mr-2" />
                Guía de Pesca
              </button>
              <select
                value={selectedCity}
                onChange={(e) => setSelectedCity(e.target.value)}
                className="bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">Todas las Ciudades</option>
                {cities.map((city) => (
                  <option key={city.id} value={city.id}>{city.name}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Sección de Rutas de Pesca */}
        {showRoutes && (
          <div className="mb-12">
            <h2 className="text-2xl font-bold text-white mb-6 flex items-center">
              <Navigation2 className="h-6 w-6 mr-2" />
              Rutas de Pesca
            </h2>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {fishingRoutes.map((route) => (
                <div key={route.id} className={`rounded-xl border p-6 hover:bg-white/5 transition-all duration-300 ${getRouteColor(route.difficulty)}`}>
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-xl font-semibold text-white">
                      {route.nameEs}
                    </h3>
                    <span className={`px-3 py-1 rounded text-sm font-medium ${
                      route.difficulty === 'Fácil' ? 'bg-green-500/20 text-green-400' :
                      route.difficulty === 'Medio' ? 'bg-yellow-500/20 text-yellow-400' :
                      route.difficulty === 'Medio-Difícil' ? 'bg-orange-500/20 text-orange-400' :
                      route.difficulty === 'Difícil' ? 'bg-red-500/20 text-red-400' :
                      'bg-purple-500/20 text-purple-400'
                    }`}>
                      {route.difficulty}
                    </span>
                  </div>

                  <p className="text-gray-300 text-sm mb-4">
                    {route.descriptionEs}
                  </p>

                  <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
                    <div>
                      <span className="text-gray-400">Tiempo Total:</span>
                      <div className="text-white font-medium">{route.totalTime}</div>
                    </div>
                    <div>
                      <span className="text-gray-400">Ganancia Total:</span>
                      <div className="text-green-400 font-medium">{route.totalProfit}</div>
                    </div>
                  </div>

                  <div className="mb-4">
                    <span className="text-gray-400 text-sm">Zonas:</span>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {route.zones.map((zoneId) => {
                        const zone = fishingZones.find(z => z.id === zoneId);
                        return (
                          <span key={zoneId} className="px-2 py-1 bg-blue-500/20 text-blue-400 text-xs rounded">
                            {zone?.name}
                          </span>
                        );
                      })}
                    </div>
                  </div>

                  <div className="mb-4">
                    <h4 className="text-white font-medium mb-2 flex items-center">
                      <Brain className="h-4 w-4 mr-2" />
                      Recomendaciones IA
                    </h4>
                    <div className="space-y-2">
                      {checkPremiumAccess('ai_recommendations') ? (
                        route.aiRecommendationsEs.map((rec, index) => (
                          <div key={index} className="flex items-start text-sm text-gray-300">
                            <CheckCircle className="h-4 w-4 text-green-400 mr-2 mt-0.5 flex-shrink-0" />
                            {rec}
                          </div>
                        ))
                      ) : (
                        <div className="bg-purple-900/20 border border-purple-500/30 rounded-lg p-4">
                          <div className="flex items-center justify-center text-purple-300 mb-2">
                            <Lock className="w-5 h-5 mr-2" />
                            Recomendaciones de IA Premium
                          </div>
                          <div className="text-center text-sm text-purple-400 mb-3">
                            Desbloquea recomendaciones personalizadas y estrategias avanzadas
                          </div>
                          <button
                            onClick={() => setShowPremiumModal(true)}
                            className="w-full bg-purple-600 hover:bg-purple-700 text-white py-2 px-4 rounded-lg text-sm transition-colors"
                          >
                            Ver Planes Premium
                          </button>
                        </div>
                      )}
                    </div>
                  </div>

                  <button
                    onClick={() => setSelectedRoute(selectedRoute === route.id ? null : route.id)}
                    className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-medium py-2 px-4 rounded-lg transition-colors"
                  >
                    {selectedRoute === route.id ? 'Ocultar Detalles' : 'Iniciar Ruta'}
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Zonas de Pesca */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {filteredZones.map((zone) => {
            const config = getRecommendedConfig(zone);
            return (
              <div key={zone.id} className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-6 hover:bg-white/10 transition-all duration-300">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xl font-semibold text-white">{zone.name}</h3>
                  <div className="flex items-center space-x-2">
                    <span className={`px-2 py-1 rounded text-xs font-medium ${getDangerColor(zone.danger)}`}>
                      {zone.danger}
                    </span>
                    <span className="text-blue-400 text-sm">{zone.tier}</span>
                  </div>
                </div>

                <p className="text-gray-300 text-sm mb-4">{zone.description}</p>

                {/* Consejos de Configuración Recomendada */}
                {showTips && config && checkPremiumAccess('ai_recommendations') && (
                  <div className="bg-gradient-to-r from-blue-500/10 to-purple-500/10 rounded-lg p-4 mb-4 border border-blue-500/20">
                    <h4 className="text-blue-400 font-semibold mb-3 flex items-center">
                      <Settings className="h-4 w-4 mr-2" />
                      Configuración Recomendada
                    </h4>
                    <div className="space-y-2 text-sm">
                      <div>
                        <span className="text-gray-400">Equipo:</span>
                        <span className="text-white ml-2">{config.gear}</span>
                        <span className="text-yellow-400 ml-2">({config.gearCost.toLocaleString()} plata)</span>
                      </div>
                      <div>
                        <span className="text-gray-400">Carnada:</span>
                        <span className="text-green-400 ml-2">{config.bait}</span>
                        <span className="text-yellow-400 ml-2">({config.baitCost.toLocaleString()} plata c/u)</span>
                      </div>
                      <div>
                        <span className="text-gray-400">Horario:</span>
                        <span className="text-yellow-400 ml-2">{config.timing}</span>
                      </div>
                      <div>
                        <span className="text-gray-400">Estrategia:</span>
                        <span className="text-cyan-400 ml-2">{config.strategy}</span>
                      </div>
                      <div>
                        <span className="text-gray-400">Ganancia Esperada:</span>
                        <span className="text-purple-400 ml-2">{config.expectedProfit}</span>
                      </div>
                      <div>
                        <span className="text-gray-400">Inversión Total:</span>
                        <span className="text-orange-400 ml-2">{config.totalInvestment.toLocaleString()} plata</span>
                      </div>
                      <div>
                        <span className="text-gray-400">Riesgo:</span>
                        <span className="text-orange-400 ml-2">{config.riskLevel}</span>
                      </div>
                    </div>
                  </div>
                )}

                {/* Mensaje para usuarios sin acceso premium */}
                {showTips && config && !checkPremiumAccess('ai_recommendations') && (
                  <div className="bg-purple-900/20 border border-purple-500/30 rounded-lg p-4 mb-4">
                    <div className="flex items-center justify-center text-purple-300 mb-2">
                      <Lock className="w-5 h-5 mr-2" />
                      Tips Avanzados de IA Premium
                    </div>
                    <div className="text-center text-sm text-purple-400 mb-3">
                      Obtén recomendaciones personalizadas de equipamiento, horarios óptimos y estrategias avanzadas
                    </div>
                    <button
                      onClick={() => setShowPremiumModal(true)}
                      className="w-full bg-purple-600 hover:bg-purple-700 text-white py-2 px-4 rounded-lg text-sm transition-colors"
                    >
                      Desbloquear Tips Premium
                    </button>
                  </div>
                )}

                <div className="space-y-3 mb-4">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-400">Coordenadas:</span>
                    <span className="text-white font-mono text-sm">{zone.coordinates}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-400">Nivel de Ganancia:</span>
                    <span className={`font-semibold ${getProfitColor(zone.profit)}`}>{zone.profit}</span>
                  </div>
                </div>

                {/* Datos del Mercado */}
                <div className="bg-gray-800/50 rounded-lg p-4 mb-4">
                  <h4 className="text-white font-medium mb-3 flex items-center">
                    <TrendingUp className="h-4 w-4 mr-2" />
                    Análisis de Mercado en Vivo
                  </h4>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-gray-400">Ganancia Promedio:</span>
                      <div className={`font-bold ${getProfitColor(zone.profit)}`}>
                        {zone.marketData.avgProfit}
                      </div>
                    </div>
                    <div>
                      <span className="text-gray-400">Tendencia del Mercado:</span>
                      <div className={`font-medium ${
                        zone.marketData.marketTrend === 'subiendo' ? 'text-green-400' :
                        zone.marketData.marketTrend === 'bajando' ? 'text-red-400' :
                        zone.marketData.marketTrend === 'volátil' || zone.marketData.marketTrend === 'altamente volátil' ? 'text-yellow-400' :
                        'text-gray-400'
                      }`}>
                        {zone.marketData.marketTrend}
                      </div>
                    </div>
                    <div>
                      <span className="text-gray-400">Competencia:</span>
                      <div className="text-white font-medium">{zone.marketData.competition}</div>
                    </div>
                    <div>
                      <span className="text-gray-400">Costo de Transporte:</span>
                      <div className="text-white font-medium">{zone.marketData.transportCost} plata</div>
                    </div>
                  </div>
                </div>

                {/* Peces con Precios en Vivo */}
                <div className="mb-4">
                  <h4 className="text-white font-medium mb-3 flex items-center">
                    <Fish className="h-4 w-4 mr-2" />
                    Peces Disponibles y Precios de Mercado en Vivo
                  </h4>
                  <div className="space-y-2">
                    {zone.fish.map((fish, index) => (
                      <div key={index} className="flex items-center justify-between bg-blue-500/10 p-3 rounded">
                        <div>
                          <span className="text-blue-400 font-medium">{fish.name}</span>
                          <span className="ml-2 text-xs text-purple-400">
                            Encantamiento: {fish.enchant}
                          </span>
                        </div>
                        <div className="text-right">
                          <div className="text-green-400 font-bold flex items-center">
                            {livePrices[fish.name] ? livePrices[fish.name].toLocaleString() : fish.basePrice.toLocaleString()}
                            {marketTrends[fish.name] && (
                              <span className={`ml-2 text-xs ${
                                marketTrends[fish.name].trend === 'rising' ? 'text-green-300' :
                                marketTrends[fish.name].trend === 'falling' ? 'text-red-300' :
                                'text-gray-300'
                              }`}>
                                {marketTrends[fish.name].trend === 'rising' ? '↗' :
                                 marketTrends[fish.name].trend === 'falling' ? '↘' : '→'}
                              </span>
                            )}
                            {livePrices[fish.name] && (
                              <span className="ml-2 w-2 h-2 bg-green-400 rounded-full animate-pulse"></span>
                            )}
                          </div>
                          <div className="text-xs text-gray-400">
                            plata {marketTrends[fish.name] && `• Vol: ${marketTrends[fish.name].volume}`}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Tasas de Aparición */}
                <div className="mb-4">
                  <h4 className="text-white font-medium mb-3 flex items-center">
                    <Target className="h-4 w-4 mr-2" />
                    Tasas de Aparición y Encantamiento
                  </h4>
                  <div className="grid grid-cols-3 gap-3 text-sm">
                    <div className="text-center bg-gray-500/20 p-2 rounded">
                      <div className="text-gray-400">Normal</div>
                      <div className="text-white font-bold">{zone.spawnRates.normal}</div>
                    </div>
                    <div className="text-center bg-purple-500/20 p-2 rounded">
                      <div className="text-purple-400">Encantado</div>
                      <div className="text-white font-bold">{zone.spawnRates.enchanted}</div>
                    </div>
                    <div className="text-center bg-yellow-500/20 p-2 rounded">
                      <div className="text-yellow-400">Raro</div>
                      <div className="text-white font-bold">{zone.spawnRates.rare}</div>
                    </div>
                  </div>
                </div>

                {/* Recomendaciones de Carnada */}
                <div className="mb-4">
                  <h4 className="text-white font-medium mb-3 flex items-center">
                    <Target className="h-4 w-4 mr-2" />
                    Carnada Recomendada y Eficiencia
                  </h4>
                  <div className="space-y-2">
                    {zone.baitRecommendations.map((bait, index) => (
                      <div key={index} className="flex items-center justify-between bg-green-500/10 p-3 rounded">
                        <div>
                          <span className="text-green-400 font-medium">{bait.bait}</span>
                          <span className={`ml-2 text-xs px-2 py-1 rounded ${
                            bait.effectiveness === 'Legendario' ? 'bg-orange-500/20 text-orange-400' :
                            bait.effectiveness === 'Extremo' ? 'bg-purple-500/20 text-purple-400' :
                            bait.effectiveness === 'Muy Alto' ? 'bg-cyan-500/20 text-cyan-400' :
                            bait.effectiveness === 'Alto' ? 'bg-blue-500/20 text-blue-400' :
                            'bg-yellow-500/20 text-yellow-400'
                          }`}>
                            {bait.effectiveness}
                          </span>
                        </div>
                        <div className="text-right">
                          <div className="text-white font-medium">{bait.cost}</div>
                          <div className="text-xs text-gray-400">plata</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Evaluación de Riesgo PvP */}
                <div className="mb-4">
                  <h4 className="text-white font-medium mb-3 flex items-center">
                    <Shield className="h-4 w-4 mr-2" />
                    Riesgo PvP y Seguridad
                  </h4>
                  <div className="bg-gray-800/50 rounded-lg p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-400">Nivel de Riesgo:</span>
                      <span className={`px-2 py-1 rounded text-xs font-medium ${getDangerColor(zone.pvpRisk.level)}`}>
                        {zone.pvpRisk.level}
                      </span>
                    </div>
                    <div>
                      <span className="text-gray-400">Frecuencia de Atacantes:</span>
                      <span className="text-white font-medium ml-2">{zone.pvpRisk.gankerFrequency}</span>
                    </div>
                    <div>
                      <span className="text-gray-400 text-sm">Consejos de Seguridad:</span>
                      <p className="text-gray-300 text-sm mt-1">{zone.pvpRisk.safetyTips}</p>
                    </div>
                    <div>
                      <span className="text-gray-400 text-sm">Rutas de Escape:</span>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {zone.pvpRisk.escapeRoutes.map((route, index) => (
                          <span key={index} className="px-2 py-1 bg-blue-500/20 text-blue-400 text-xs rounded">
                            <Route className="h-3 w-3 inline mr-1" />
                            {route}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Efectos Climáticos */}
                <div className="mb-4">
                  <h4 className="text-white font-medium mb-3 flex items-center">
                    <Wind className="h-4 w-4 mr-2" />
                    Bonificaciones Climáticas y Ambientales
                  </h4>
                  <div className="bg-blue-500/10 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-blue-400 font-medium">{zone.weatherEffects.current}</span>
                      <span className="flex items-center text-gray-400 text-xs">
                        <Timer className="h-3 w-3 mr-1" />
                        {zone.weatherEffects.nextChange}
                      </span>
                    </div>
                    <p className="text-green-400 text-sm">{zone.weatherEffects.bonus}</p>
                  </div>
                </div>

                {/* Recursos Adicionales */}
                <div className="mb-4">
                  <h4 className="text-white font-medium mb-2 flex items-center">
                    <Coins className="h-4 w-4 mr-2" />
                    Recursos Adicionales
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {zone.resources.map((resource, index) => (
                      <span key={index} className="px-2 py-1 bg-green-500/20 text-green-400 text-xs rounded">
                        {resource}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Transporte y Logística */}
                <div className="mb-4">
                  <h4 className="text-white font-medium mb-3 flex items-center">
                    <Truck className="h-4 w-4 mr-2" />
                    Transporte y Logística
                  </h4>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-gray-400">Transporte Base:</span>
                      <div className="text-white font-medium">{zone.marketData.transportCost} plata</div>
                    </div>
                    <div>
                      <span className="text-gray-400">Distancia al Mercado:</span>
                      <div className="text-white font-medium">
                        {Math.floor(zone.marketData.transportCost / 50)} zonas
                      </div>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <button className="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-lg transition-colors flex items-center justify-center">
                    <MapPin className="h-4 w-4 mr-2" />
                    Ver en Mapa
                  </button>
                  <button className="bg-green-600 hover:bg-green-700 text-white font-medium py-2 px-4 rounded-lg transition-colors flex items-center justify-center">
                    <TrendingUp className="h-4 w-4 mr-2" />
                    Alertas de Precios
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Panel de Análisis Avanzados */}
        <div className="mt-12 bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-8">
          <h2 className="text-2xl font-bold text-white mb-6 text-center flex items-center justify-center">
            <TrendingUp className="h-6 w-6 mr-2" />
            Análisis de Mercado en Vivo
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="bg-green-500/20 rounded-lg p-6 border border-green-500/30">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-green-400 font-semibold">Mayor Valor</h3>
                <Coins className="h-5 w-5 text-green-400" />
              </div>
              <div className="text-2xl font-bold text-white mb-2">Kraken</div>
              <div className="text-green-400 text-sm">
                {livePrices['Kraken'] ? livePrices['Kraken'].toLocaleString() : '45,000'} plata
              </div>
              <div className="text-xs text-gray-400 mt-1">🦑 Exclusivo de zona negra</div>
            </div>

            <div className="bg-blue-500/20 rounded-lg p-6 border border-blue-500/30">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-blue-400 font-semibold">Más Volátil</h3>
                <AlertTriangle className="h-5 w-5 text-blue-400" />
              </div>
              <div className="text-2xl font-bold text-white mb-2">Giant Squid</div>
              <div className="text-blue-400 text-sm">
                {livePrices['Giant Squid'] ? livePrices['Giant Squid'].toLocaleString() : '28,000'} plata
              </div>
              <div className="text-xs text-gray-400 mt-1">📈 Artículo de alta demanda</div>
            </div>

            <div className="bg-purple-500/20 rounded-lg p-6 border border-purple-500/30">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-purple-400 font-semibold">En Alza</h3>
                <TrendingUp className="h-5 w-5 text-purple-400" />
              </div>
              <div className="text-2xl font-bold text-white mb-2">Crystal Eel</div>
              <div className="text-purple-400 text-sm">
                {livePrices['Crystal Eel'] ? livePrices['Crystal Eel'].toLocaleString() : '21,000'} plata
              </div>
              <div className="text-xs text-gray-400 mt-1">⚡ Subiendo 12% hoy</div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-gray-800/50 rounded-lg p-6">
              <h3 className="text-white font-semibold mb-4 flex items-center">
                <Wind className="h-5 w-5 mr-2" />
                Bonificaciones Climáticas Actuales
              </h3>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Caerleon - Luna Sangrienta</span>
                  <span className="text-orange-400 font-medium">+50% todas las apariciones</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Martlock - Niebla Mística</span>
                  <span className="text-purple-400 font-medium">+25% apariciones raras</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Fort Sterling - Ventisca</span>
                  <span className="text-cyan-400 font-medium">+20% peces de hielo</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Thetford - Lluvia Ligera</span>
                  <span className="text-green-400 font-medium">+15% tasa de captura</span>
                </div>
              </div>
            </div>

            <div className="bg-gray-800/50 rounded-lg p-6">
              <h3 className="text-white font-semibold mb-4 flex items-center">
                <AlertTriangle className="h-5 w-5 mr-2" />
                Líderes en Volumen de Mercado
              </h3>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Shadow Eel</span>
                  <span className="text-red-400 font-medium">
                    {marketTrends['Shadow Eel'] ? marketTrends['Shadow Eel'].volume : '890'} intercambios
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Royal Shell</span>
                  <span className="text-orange-400 font-medium">
                    {marketTrends['Royal Shell'] ? marketTrends['Royal Shell'].volume : '652'} intercambios
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Ice Salmon</span>
                  <span className="text-yellow-400 font-medium">
                    {marketTrends['Ice Salmon'] ? marketTrends['Ice Salmon'].volume : '543'} intercambios
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Saltwater Cod</span>
                  <span className="text-green-400 font-medium">
                    {marketTrends['Saltwater Cod'] ? marketTrends['Saltwater Cod'].volume : '432'} intercambios
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Calculadora de Ganancias por Temporada */}
          {showSeasonCalculator && (
            <div className="mt-8">
              <div className="bg-gradient-to-r from-amber-900/30 to-orange-900/30 p-6 rounded-xl border border-amber-500/20">
                <h3 className="text-xl font-semibold text-amber-100 mb-6 flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-amber-400" />
                  Calculadora de Ganancias por Temporada
                  <Trophy className="w-4 h-4 text-yellow-400 ml-2" />
                </h3>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-amber-200 mb-2">
                      Seleccionar Zona de Pesca
                    </label>
                    <select
                      className="w-full bg-gray-800 border border-amber-500/30 rounded-lg px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                      onChange={(e) => {
                        const zoneId = parseInt(e.target.value);
                        const calculation = calculateSeasonProfits(zoneId, 4);
                        setSeasonData(calculation);
                      }}
                    >
                      <option value="">Selecciona una zona...</option>
                      {filteredZones.map((zone) => (
                        <option key={zone.id} value={zone.id}>
                          {zone.name} - {zone.profit} ganancia
                        </option>
                      ))}
                    </select>
                  </div>

                  {seasonData && (
                    <div className="bg-gray-900/50 p-4 rounded-lg">
                      <h4 className="text-lg font-semibold text-amber-100 mb-3 flex items-center gap-2">
                        <BarChart3 className="w-4 h-4" />
                        Proyecciones de Ganancia
                      </h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-300">Diaria (4h):</span>
                          <span className="text-green-400 font-medium">{seasonData.daily.toLocaleString()} plata</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-300">Semanal:</span>
                          <span className="text-green-400 font-medium">{seasonData.weekly.toLocaleString()} plata</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-300">Mensual:</span>
                          <span className="text-blue-400 font-medium">{seasonData.monthly.toLocaleString()} plata</span>
                        </div>
                        <div className="flex justify-between border-t border-gray-700 pt-2">
                          <span className="text-gray-300">Temporada (3 meses):</span>
                          <span className="text-cyan-400 font-bold">{seasonData.season.toLocaleString()} plata</span>
                        </div>
                        <div className="flex justify-between text-red-300">
                          <span>Costo de equipo:</span>
                          <span>-{seasonData.equipment.toLocaleString()} plata</span>
                        </div>
                        <div className="flex justify-between border-t border-amber-600/30 pt-2">
                          <span className="text-amber-200 font-semibold">Ganancia Neta:</span>
                          <span className="text-amber-400 font-bold text-lg">
                            {seasonData.netProfit.toLocaleString()} plata
                          </span>
                        </div>
                        <div className="mt-3 text-xs text-gray-400">
                          * Basado en 4 horas diarias de pesca con precios actuales del mercado
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Equipos Importados */}
                {importedEquipment.length > 0 && (
                  <div className="mt-6 bg-gray-900/50 p-4 rounded-lg">
                    <h4 className="text-lg font-semibold text-purple-200 mb-3 flex items-center gap-2">
                      <Download className="w-4 h-4" />
                      Equipos Importados Recientemente
                    </h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {importedEquipment.map((item, index) => (
                        <div key={index} className="flex items-center justify-between bg-gray-800/50 p-3 rounded">
                          <div>
                            <span className="text-white font-medium text-sm">{item.name}</span>
                            <div className="text-xs text-gray-400">
                              Tier {item.tier} • {item.category} • {item.lastUpdated.toLocaleTimeString()}
                            </div>
                          </div>
                          <div className="text-purple-400 font-medium">
                            {item.price.toLocaleString()} plata
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Gráficos Avanzados */}
          <div className="mt-8">
            <div className="bg-gray-800/50 p-6 rounded-lg">
              <h3 className="text-xl font-semibold text-gray-100 mb-4 flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-blue-400" />
                Análisis de Mercado Avanzado
              </h3>
              <p className="text-gray-400">Gráficos y análisis de tendencias disponibles próximamente.</p>
            </div>
          </div>
        </div>

        {/* Mapa Interactivo */}
        <div className="mt-12 bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-8">
          <h2 className="text-2xl font-bold text-white mb-6 text-center">
            Mapa Mundial Interactivo
          </h2>
          <div className="aspect-video bg-gray-800 rounded-lg flex items-center justify-center">
            <div className="text-center">
              <MapPin className="h-16 w-16 text-blue-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">
                Mapa Interactivo Próximamente
              </h3>
              <p className="text-gray-400">
                Mapa interactivo completo con datos de zona en tiempo real y recomendaciones de IA
              </p>
              <div className="mt-4 text-sm text-gray-500">
                Características: Seguimiento de jugadores en vivo • Aparición de nodos de recursos • Control territorial de gremios • Superposición climática • Mapas de calor de precios
              </div>
            </div>
          </div>
        </div>
      </div>

      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onLogin={handleLogin}
      />

      {/* Modal de Tutorial */}
      {showTutorial && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className={`bg-gradient-to-br from-green-900 to-green-800 rounded-2xl max-w-2xl w-full ${tutorialMinimized ? 'h-auto' : 'max-h-[90vh]'} overflow-y-auto border border-green-500/30`}>
            <div className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-bold text-white flex items-center gap-3">
                  <BookOpen className="w-6 h-6 text-green-400" />
                  Tutorial de Pesca - Paso {currentTutorialStep + 1} de {tutorialSteps.length}
                </h2>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setTutorialMinimized(!tutorialMinimized)}
                    className="text-green-400 hover:text-white transition-colors"
                  >
                    {tutorialMinimized ? <Maximize2 className="w-5 h-5" /> : <Minimize2 className="w-5 h-5" />}
                  </button>
                  <button
                    onClick={() => setShowTutorial(false)}
                    className="text-green-400 hover:text-white transition-colors"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>
              </div>

              {!tutorialMinimized && (
                <div>
                  <div className="mb-6">
                    <h3 className="text-xl font-semibold text-green-200 mb-3">
                      {tutorialSteps[currentTutorialStep].title}
                    </h3>
                    <p className="text-green-100 leading-relaxed">
                      {tutorialSteps[currentTutorialStep].content}
                    </p>
                  </div>

                  <div className="flex justify-between items-center">
                    <button
                      onClick={() => setCurrentTutorialStep(Math.max(0, currentTutorialStep - 1))}
                      disabled={currentTutorialStep === 0}
                      className="bg-green-700 hover:bg-green-600 disabled:bg-gray-600 disabled:cursor-not-allowed text-white px-4 py-2 rounded-lg transition-colors"
                    >
                      Anterior
                    </button>

                    <div className="flex items-center space-x-2">
                      {tutorialSteps.map((_, index) => (
                        <div
                          key={index}
                          className={`w-3 h-3 rounded-full ${
                            index === currentTutorialStep ? 'bg-green-400' : index < currentTutorialStep ? 'bg-green-600' : 'bg-gray-600'
                          }`}
                        />
                      ))}
                    </div>

                    <button
                      onClick={() => {
                        if (currentTutorialStep < tutorialSteps.length - 1) {
                          setCurrentTutorialStep(currentTutorialStep + 1);
                        } else {
                          setShowTutorial(false);
                        }
                      }}
                      className="bg-green-600 hover:bg-green-500 text-white px-4 py-2 rounded-lg transition-colors"
                    >
                      {currentTutorialStep === tutorialSteps.length - 1 ? 'Completar' : 'Siguiente'}
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Modal de Guía de Pesca */}
      {showFishingGuide && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className={`bg-gradient-to-br from-blue-900 to-blue-800 rounded-2xl max-w-4xl w-full ${guideMinimized ? 'h-auto' : 'max-h-[90vh]'} overflow-y-auto border border-blue-500/30`}>
            <div className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-bold text-white flex items-center gap-3">
                  <HelpCircle className="w-6 h-6 text-blue-400" />
                  Guía Completa de Pesca - Paso {currentGuideStep + 1}: {fishingGuideSteps[currentGuideStep].title}
                </h2>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setGuideMinimized(!guideMinimized)}
                    className="text-blue-400 hover:text-white transition-colors"
                  >
                    {guideMinimized ? <Maximize2 className="w-5 h-5" /> : <Minimize2 className="w-5 h-5" />}
                  </button>
                  <button
                    onClick={() => setShowFishingGuide(false)}
                    className="text-blue-400 hover:text-white transition-colors"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>
              </div>

              {!guideMinimized && (
                <div>
                  <div className="mb-6">
                    <p className="text-blue-100 mb-4 text-lg">
                      {fishingGuideSteps[currentGuideStep].description}
                    </p>

                    <div className="grid md:grid-cols-3 gap-4 mb-4">
                      <div className="bg-blue-800/30 rounded-lg p-4">
                        <h4 className="text-blue-300 font-semibold mb-2 flex items-center">
                          <Package className="w-4 h-4 mr-2" />
                          Equipamiento Necesario
                        </h4>
                        <ul className="space-y-1">
                          {fishingGuideSteps[currentGuideStep].equipment.map((item, index) => (
                            <li key={index} className="text-blue-200 text-sm">• {item}</li>
                          ))}
                        </ul>
                      </div>

                      <div className="bg-green-800/30 rounded-lg p-4">
                        <h4 className="text-green-300 font-semibold mb-2 flex items-center">
                          <CheckCircle className="w-4 h-4 mr-2" />
                          Consejos Pro
                        </h4>
                        <ul className="space-y-1">
                          {fishingGuideSteps[currentGuideStep].tips.map((tip, index) => (
                            <li key={index} className="text-green-200 text-sm">• {tip}</li>
                          ))}
                        </ul>
                      </div>

                      <div className="bg-red-800/30 rounded-lg p-4">
                        <h4 className="text-red-300 font-semibold mb-2 flex items-center">
                          <AlertTriangle className="w-4 h-4 mr-2" />
                          Advertencias
                        </h4>
                        <ul className="space-y-1">
                          {fishingGuideSteps[currentGuideStep].warnings.map((warning, index) => (
                            <li key={index} className="text-red-200 text-sm">⚠️ {warning}</li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>

                  <div className="flex justify-between items-center">
                    <button
                      onClick={() => setCurrentGuideStep(Math.max(0, currentGuideStep - 1))}
                      disabled={currentGuideStep === 0}
                      className="bg-blue-700 hover:bg-blue-600 disabled:bg-gray-600 disabled:cursor-not-allowed text-white px-4 py-2 rounded-lg transition-colors"
                    >
                      Paso Anterior
                    </button>

                    <div className="flex items-center space-x-2">
                      {fishingGuideSteps.map((_, index) => (
                        <button
                          key={index}
                          onClick={() => setCurrentGuideStep(index)}
                          className={`w-8 h-8 rounded-full text-sm font-medium transition-colors ${
                            index === currentGuideStep ? 'bg-blue-500 text-white' : index < currentGuideStep ? 'bg-blue-600 text-blue-200' : 'bg-gray-600 text-gray-400'
                          }`}
                        >
                          {index + 1}
                        </button>
                      ))}
                    </div>

                    <button
                      onClick={() => {
                        if (currentGuideStep < fishingGuideSteps.length - 1) {
                          setCurrentGuideStep(currentGuideStep + 1);
                        } else {
                          setShowFishingGuide(false);
                        }
                      }}
                      className="bg-blue-600 hover:bg-blue-500 text-white px-4 py-2 rounded-lg transition-colors"
                    >
                      {currentGuideStep === fishingGuideSteps.length - 1 ? 'Finalizar Guía' : 'Siguiente Paso'}
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Modal de Planes Premium */}
      {showPremiumModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto border border-purple-500/30">
            <div className="p-8">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-3xl font-bold text-white flex items-center gap-3">
                  <Crown className="w-8 h-8 text-yellow-400" />
                  Planes Premium
                </h2>
                <button
                  onClick={() => setShowPremiumModal(false)}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="grid md:grid-cols-3 gap-6">
                {/* Plan Gratuito */}
                <div className="bg-gray-800/50 rounded-xl p-6 border border-gray-700">
                  <div className="text-center mb-6">
                    <h3 className="text-xl font-semibold text-gray-200 mb-2">Gratuito</h3>
                    <div className="text-3xl font-bold text-gray-400">$0</div>
                    <div className="text-gray-500 text-sm">Por siempre</div>
                  </div>
                  <ul className="space-y-3 mb-6">
                    <li className="flex items-center text-gray-300">
                      <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                      Mapas básicos de pesca
                    </li>
                    <li className="flex items-center text-gray-300">
                      <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                      Precios de mercado básicos
                    </li>
                    <li className="flex items-center text-gray-400">
                      <X className="w-4 h-4 text-red-500 mr-2" />
                      Calculadora de temporada
                    </li>
                    <li className="flex items-center text-gray-400">
                      <X className="w-4 h-4 text-red-500 mr-2" />
                      Importación de equipos
                    </li>
                  </ul>
                  <div className="text-center text-green-400 font-medium">Plan Actual</div>
                </div>

                {/* Plan Premium */}
                <div className="bg-gradient-to-br from-purple-900/50 to-blue-900/50 rounded-xl p-6 border border-purple-500 relative">
                  <div className="absolute top-0 right-4 bg-purple-500 text-white px-3 py-1 rounded-b-lg text-sm font-medium">
                    Más Popular
                  </div>
                  <div className="text-center mb-6">
                    <h3 className="text-xl font-semibold text-purple-200 mb-2">Premium</h3>
                    <div className="text-3xl font-bold text-purple-300">$9.99</div>
                    <div className="text-purple-400 text-sm">Por mes</div>
                  </div>
                  <ul className="space-y-3 mb-6">
                    <li className="flex items-center text-purple-200">
                      <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                      Todo lo del plan gratuito
                    </li>
                    <li className="flex items-center text-purple-200">
                      <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                      Calculadora de ganancias por temporada
                    </li>
                    <li className="flex items-center text-purple-200">
                      <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                      Importación automática de equipos
                    </li>
                    <li className="flex items-center text-purple-200">
                      <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                      Recomendaciones avanzadas de IA
                    </li>
                    <li className="flex items-center text-purple-300">
                      <X className="w-4 h-4 text-red-400 mr-2" />
                      Alertas de precios
                    </li>
                  </ul>
                  <button
                    onClick={() => upgradeToPremium('premium')}
                    className="w-full bg-purple-600 hover:bg-purple-700 text-white font-medium py-3 rounded-lg transition-colors"
                  >
                    Actualizar a Premium
                  </button>
                </div>

                {/* Plan Pro */}
                <div className="bg-gradient-to-br from-amber-900/50 to-orange-900/50 rounded-xl p-6 border border-amber-500">
                  <div className="text-center mb-6">
                    <h3 className="text-xl font-semibold text-amber-200 mb-2">Pro</h3>
                    <div className="text-3xl font-bold text-amber-300">$19.99</div>
                    <div className="text-amber-400 text-sm">Por mes</div>
                  </div>
                  <ul className="space-y-3 mb-6">
                    <li className="flex items-center text-amber-200">
                      <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                      Todo lo del plan Premium
                    </li>
                    <li className="flex items-center text-amber-200">
                      <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                      Rutas avanzadas optimizadas
                    </li>
                    <li className="flex items-center text-amber-200">
                      <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                      Sistema de alertas de precios
                    </li>
                    <li className="flex items-center text-amber-200">
                      <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                      Herramientas para guilds
                    </li>
                    <li className="flex items-center text-amber-200">
                      <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                      API access para desarrolladores
                    </li>
                  </ul>
                  <button
                    onClick={() => upgradeToPremium('pro')}
                    className="w-full bg-amber-600 hover:bg-amber-700 text-white font-medium py-3 rounded-lg transition-colors"
                  >
                    Actualizar a Pro
                  </button>
                </div>
              </div>

              <div className="mt-8 bg-gray-800/30 rounded-lg p-4">
                <div className="text-center">
                  <h4 className="text-lg font-semibold text-white mb-2">
                    🎯 ¿Por qué elegir un plan premium?
                  </h4>
                  <div className="grid md:grid-cols-3 gap-4 text-sm text-gray-300">
                    <div className="flex items-center">
                      <TrendingUp className="w-4 h-4 text-green-400 mr-2" />
                      Maximiza tus ganancias con análisis precisos
                    </div>
                    <div className="flex items-center">
                      <Timer className="w-4 h-4 text-blue-400 mr-2" />
                      Ahorra tiempo con automatización
                    </div>
                    <div className="flex items-center">
                      <Brain className="w-4 h-4 text-purple-400 mr-2" />
                      Decisiones inteligentes basadas en datos
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}