import { useState } from 'react';
import { Crown, Check, Zap, Bot, TrendingUp, Shield, Star, Gift } from 'lucide-react';
import Navigation from '../components/Navigation';
import AuthModal from '../components/AuthModal';

export default function Premium() {
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [user, setUser] = useState(null);
  const [activationCode, setActivationCode] = useState('');

  const handleLogin = (userData: any) => {
    setUser(userData);
  };

  const handleActivateCode = () => {
    // Simulate code activation
    alert('Premium activated successfully!');
    setActivationCode('');
  };

  const premiumFeatures = [
    {
      icon: Bot,
      title: 'Advanced AI Assistant',
      description: 'Unlimited access to our AI fishing expert with personalized strategies',
      free: 'Limited queries',
      premium: 'Unlimited + Priority responses'
    },
    {
      icon: TrendingUp,
      title: 'Real-Time Market Alerts',
      description: 'Get instant notifications for price changes and profit opportunities',
      free: 'Basic price data',
      premium: 'Real-time alerts + Predictions'
    },
    {
      icon: Zap,
      title: 'Auto Inventory Optimizer',
      description: 'AI-powered inventory management with automatic recommendations',
      free: 'Manual tracking',
      premium: 'Full automation + Smart alerts'
    },
    {
      icon: Shield,
      title: 'Risk Assessment Tools',
      description: 'Advanced zone safety analysis and PvP risk calculations',
      free: 'Basic zone info',
      premium: 'Advanced risk analysis + Predictions'
    },
    {
      icon: Star,
      title: 'Exclusive Content',
      description: 'Access to premium builds, strategies, and insider market data',
      free: 'Basic guides',
      premium: 'Exclusive content + Early access'
    },
    {
      icon: Gift,
      title: 'Priority Support',
      description: 'Get priority customer support and feature requests',
      free: 'Community support',
      premium: '24/7 priority support + Direct access'
    }
  ];

  const pricingPlans = [
    {
      name: 'Free',
      price: 0,
      period: 'Forever',
      features: [
        'Basic fishing maps',
        'Simple profit calculator',
        'Limited AI queries (5/day)',
        'Basic market data',
        'Community support'
      ],
      color: 'gray',
      popular: false
    },
    {
      name: 'Premium Monthly',
      price: 9.99,
      period: 'per month',
      features: [
        'Everything in Free',
        'Unlimited AI assistant',
        'Real-time market alerts',
        'Advanced risk analysis',
        'Auto inventory optimization',
        'Exclusive content access',
        'Priority support'
      ],
      color: 'blue',
      popular: true
    },
    {
      name: 'Premium Yearly',
      price: 99.99,
      period: 'per year',
      features: [
        'Everything in Monthly',
        '2 months free',
        'Early feature access',
        'Custom strategy sessions',
        'API access (coming soon)',
        'White-label options'
      ],
      color: 'purple',
      popular: false,
      savings: '17% off'
    }
  ];

  const testimonials = [
    {
      name: 'FishMaster2024',
      guild: 'Elite Fishers',
      message: "Premium AI recommendations increased my profit by 300%. Best investment I've made in Albion!",
      rating: 5
    },
    {
      name: 'OceanHunter',
      guild: 'Deep Sea Crew',
      message: "The real-time alerts helped me catch market spikes I would have missed. Paid for itself in a week.",
      rating: 5
    },
    {
      name: 'SilentAngler',
      guild: 'Shadow Fishers',
      message: "Risk assessment tools saved me from multiple ganks. Premium is essential for black zone fishing.",
      rating: 5
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-900 to-blue-900">
      <Navigation onAuthClick={() => setIsAuthModalOpen(true)} user={user} />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center px-4 py-2 rounded-full bg-gradient-to-r from-yellow-500/20 to-orange-500/20 border border-yellow-500/30 text-yellow-400 text-sm font-medium mb-8">
            <Crown className="h-4 w-4 mr-2" />
            Unlock Premium Features
          </div>
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-4">
            Dominate Albion's
            <span className="block bg-gradient-to-r from-yellow-400 via-orange-400 to-red-500 bg-clip-text text-transparent">
              Fishing Economy
            </span>
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Join elite fishers who use advanced AI tools and real-time data to maximize their profits and minimize risks
          </p>
        </div>

        {/* Feature Comparison */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-white text-center mb-12">Why Upgrade to Premium?</h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {premiumFeatures.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <div key={index} className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-6 hover:bg-white/10 transition-all duration-300">
                  <div className="flex items-start space-x-4">
                    <div className="p-3 bg-gradient-to-r from-blue-500/20 to-purple-500/20 rounded-lg">
                      <Icon className="h-6 w-6 text-blue-400" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-white mb-2">{feature.title}</h3>
                      <p className="text-gray-300 text-sm mb-4">{feature.description}</p>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <p className="text-xs font-medium text-gray-400 mb-1">FREE</p>
                          <p className="text-sm text-gray-300">{feature.free}</p>
                        </div>
                        <div>
                          <p className="text-xs font-medium text-yellow-400 mb-1">PREMIUM</p>
                          <p className="text-sm text-white font-medium">{feature.premium}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Pricing Plans */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-white text-center mb-12">Choose Your Plan</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {pricingPlans.map((plan, index) => (
              <div key={index} className={`relative bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-6 hover:bg-white/10 transition-all duration-300 ${
                plan.popular ? 'ring-2 ring-blue-500/50 scale-105' : ''
              }`}>
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <span className="bg-gradient-to-r from-blue-600 to-purple-600 text-white text-xs font-bold px-3 py-1 rounded-full">
                      MOST POPULAR
                    </span>
                  </div>
                )}
                {plan.savings && (
                  <div className="absolute -top-3 right-4">
                    <span className="bg-green-600 text-white text-xs font-bold px-2 py-1 rounded">
                      {plan.savings}
                    </span>
                  </div>
                )}

                <div className="text-center mb-6">
                  <h3 className="text-xl font-semibold text-white mb-2">{plan.name}</h3>
                  <div className="mb-2">
                    <span className="text-3xl font-bold text-white">${plan.price}</span>
                    <span className="text-gray-400 ml-2">{plan.period}</span>
                  </div>
                </div>

                <ul className="space-y-3 mb-6">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center text-sm">
                      <Check className="h-4 w-4 text-green-400 mr-2 flex-shrink-0" />
                      <span className="text-gray-300">{feature}</span>
                    </li>
                  ))}
                </ul>

                <button className={`w-full py-3 px-4 rounded-lg font-semibold transition-all duration-300 ${
                  plan.name === 'Free'
                    ? 'bg-gray-700 hover:bg-gray-600 text-white'
                    : plan.popular
                    ? 'bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white transform hover:scale-105'
                    : 'bg-white/10 hover:bg-white/20 text-white border border-white/20'
                }`}>
                  {plan.name === 'Free' ? 'Current Plan' : 'Upgrade Now'}
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Code Activation */}
        <div className="mb-16">
          <div className="max-w-md mx-auto bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-6">
            <h3 className="text-xl font-semibold text-white text-center mb-4">Have a Premium Code?</h3>
            <p className="text-gray-300 text-sm text-center mb-6">
              Enter your premium activation code to unlock all features instantly
            </p>
            <div className="space-y-4">
              <input
                type="text"
                value={activationCode}
                onChange={(e) => setActivationCode(e.target.value)}
                placeholder="Enter premium code"
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <button
                onClick={handleActivateCode}
                disabled={!activationCode}
                className="w-full bg-green-600 hover:bg-green-700 disabled:bg-gray-700 disabled:cursor-not-allowed text-white font-medium py-2 px-4 rounded-lg transition-colors"
              >
                Activate Code
              </button>
            </div>
          </div>
        </div>

        {/* Testimonials */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-white text-center mb-12">What Premium Users Say</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-6">
                <div className="flex items-center mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-300 italic mb-4">"{testimonial.message}"</p>
                <div>
                  <p className="text-white font-semibold">{testimonial.name}</p>
                  <p className="text-gray-400 text-sm">{testimonial.guild}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* FAQ */}
        <div className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-8">
          <h2 className="text-2xl font-bold text-white text-center mb-8">Frequently Asked Questions</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h4 className="text-white font-semibold mb-2">Can I cancel anytime?</h4>
              <p className="text-gray-300 text-sm">Yes, you can cancel your subscription at any time. You'll continue to have access until the end of your billing period.</p>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-2">Do you offer refunds?</h4>
              <p className="text-gray-300 text-sm">We offer a 7-day money-back guarantee if you're not satisfied with Premium features.</p>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-2">Is my data secure?</h4>
              <p className="text-gray-300 text-sm">Absolutely. We use enterprise-grade encryption and never store sensitive game credentials.</p>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-2">How do premium codes work?</h4>
              <p className="text-gray-300 text-sm">Premium codes provide instant access to all features. Codes are distributed through partnerships and special events.</p>
            </div>
          </div>
        </div>
      </div>

      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onLogin={handleLogin}
      />
    </div>
  );
}