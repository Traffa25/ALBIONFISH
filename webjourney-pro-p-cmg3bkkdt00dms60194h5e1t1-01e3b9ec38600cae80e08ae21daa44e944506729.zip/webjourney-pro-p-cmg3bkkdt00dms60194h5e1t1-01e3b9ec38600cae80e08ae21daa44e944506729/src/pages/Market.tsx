import { useState, useMemo, useCallback } from 'react';
import { TrendingUp, TrendingDown, DollarSign, BarChart3, RefreshCw, Zap, AlertTriangle, Target, Map, Compass, Navigation as NavIcon, Fish, Waves, X, MapPin, Users } from 'lucide-react';
import Navigation from '../components/Navigation';
import AuthModal from '../components/AuthModal';

export default function Market() {
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [user, setUser] = useState(null);
  const [goldPrice, setGoldPrice] = useState(4250);
  const [isUpdating, setIsUpdating] = useState(false);
  const [selectedFilter, setSelectedFilter] = useState('all');
  const [selectedCity, setSelectedCity] = useState<string | null>(null);
  const [isMapModalOpen, setIsMapModalOpen] = useState(false);

  const handleLogin = (userData: any) => {
    setUser(userData);
  };

  const updatePrices = () => {
    setIsUpdating(true);
    setTimeout(() => {
      setGoldPrice(prev => prev + Math.floor(Math.random() * 200) - 100);
      setIsUpdating(false);
    }, 2000);
  };

  // Memoized fish data for performance optimization
  const freshwaterFish = useMemo(() => [
    { id: 'fw1', name: 'Rudd común', type: 'agua dulce', rarity: 'Común', level: 1, zones: '2-3', price: 45, trend: '+5%', volume: 5420 },
    { id: 'fw2', name: 'Carpa rayada', type: 'agua dulce', rarity: 'Común', level: 2, zones: '2-4', price: 65, trend: '+8%', volume: 4830 },
    { id: 'fw3', name: 'Perca Albion', type: 'agua dulce', rarity: 'Común', level: 3, zones: '3-5', price: 95, trend: '-3%', volume: 3240 },
    { id: 'fw4', name: 'Lucio de escala de blues', type: 'agua dulce', rarity: 'Común', level: 4, zones: '4-6', price: 145, trend: '+12%', volume: 2847 },
    { id: 'fw5', name: 'Trucha manchada', type: 'agua dulce', rarity: 'Común', level: 5, zones: '5-7', price: 220, trend: '+15%', volume: 1950 },
    { id: 'fw6', name: 'Zander en escala brillante', type: 'agua dulce', rarity: 'Común', level: 6, zones: '6-8', price: 340, trend: '+18%', volume: 1420 },
    { id: 'fw7', name: 'Bagre de boca colgante', type: 'agua dulce', rarity: 'Común', level: 7, zones: '7-8', price: 485, trend: '+22%', volume: 890 },
    { id: 'fw8', name: 'Esturión de río', type: 'agua dulce', rarity: 'Común', level: 8, zones: '8', price: 720, trend: '+25%', volume: 560 }
  ], []);

  const saltwaterFish = useMemo(() => [
    { id: 'sw1', name: 'Arenque común', type: 'Agua salada', rarity: 'Común', level: 1, zones: '2-3', price: 48, trend: '+4%', volume: 5120 },
    { id: 'sw2', name: 'Caballa rayada', type: 'Agua salada', rarity: 'Común', level: 2, zones: '2-4', price: 68, trend: '+7%', volume: 4620 },
    { id: 'sw3', name: 'Platija de costa plana', type: 'Agua salada', rarity: 'Común', level: 3, zones: '3-5', price: 98, trend: '-2%', volume: 3180 },
    { id: 'sw4', name: 'Bacalao de escala azul', type: 'Agua salada', rarity: 'Común', level: 4, zones: '4-6', price: 148, trend: '+10%', volume: 2720 },
    { id: 'sw5', name: 'Pez lobo manchado', type: 'Agua salada', rarity: 'Común', level: 5, zones: '5-7', price: 225, trend: '+14%', volume: 1880 },
    { id: 'sw6', name: 'Salmón de aleta fuerte', type: 'Agua salada', rarity: 'Común', level: 6, zones: '6-8', price: 345, trend: '+17%', volume: 1350 },
    { id: 'sw7', name: 'Atún rojo', type: 'Agua salada', rarity: 'Común', level: 7, zones: '7-8', price: 490, trend: '+21%', volume: 840 },
    { id: 'sw8', name: 'Pez espada a escala de acero', type: 'Agua salada', rarity: 'Común', level: 8, zones: '8', price: 725, trend: '+24%', volume: 520 }
  ], []);

  const rareFish = useMemo(() => [
    { id: 'r1', name: 'Anguila de río verde', type: 'agua dulce', rarity: 'Raro', level: 3, zones: '3-8', biome: 'Bosque, Pantano, Highland', price: 580, trend: '+35%', volume: 120 },
    { id: 'r2', name: 'Anguila de primavera roja', type: 'agua dulce', rarity: 'Raro', level: 5, zones: '5-8', biome: 'Bosque, Pantano, Highland', price: 890, trend: '+42%', volume: 85 },
    { id: 'r3', name: 'Anguila de agua muerta', type: 'agua dulce', rarity: 'Raro', level: 7, zones: '7-8', biome: 'Bosque, Pantano, Highland', price: 1450, trend: '+55%', volume: 45 },
    { id: 'r4', name: 'Acechador de corriente de piedra', type: 'agua dulce', rarity: 'Raro', level: 3, zones: '3-8', biome: 'Highland, Montaña, Bosque', price: 620, trend: '+38%', volume: 110 },
    { id: 'r5', name: 'Lurcher de agua de junco', type: 'agua dulce', rarity: 'Raro', level: 5, zones: '5-8', biome: 'Highland, Montaña, Bosque', price: 920, trend: '+45%', volume: 78 },
    { id: 'r6', name: 'Acechador de truenos', type: 'agua dulce', rarity: 'Raro', level: 7, zones: '7-8', biome: 'Highland, Montaña, Bosque', price: 1520, trend: '+58%', volume: 42 },
    { id: 'r7', name: 'Almeja de Greenmoor', type: 'agua dulce', rarity: 'Raro', level: 3, zones: '3-8', biome: 'Pantano, Estepa, Montaña', price: 650, trend: '+40%', volume: 105 },
    { id: 'r8', name: 'Almeja de agua murk', type: 'agua dulce', rarity: 'Raro', level: 5, zones: '5-8', biome: 'Pantano, Estepa, Montaña', price: 980, trend: '+48%', volume: 72 },
    { id: 'r9', name: 'Almeja Blackbog', type: 'agua dulce', rarity: 'Raro', level: 7, zones: '7-8', biome: 'Pantano, Estepa, Montaña', price: 1620, trend: '+62%', volume: 38 },
    { id: 'r10', name: 'Coldeye de las tierras altas', type: 'agua dulce', rarity: 'Raro', level: 3, zones: '3-8', biome: 'Montaña, Highland, Estepa', price: 680, trend: '+42%', volume: 98 },
    { id: 'r11', name: 'Ojo ciego de montaña', type: 'agua dulce', rarity: 'Raro', level: 5, zones: '5-8', biome: 'Montaña, Highland, Estepa', price: 1020, trend: '+50%', volume: 68 },
    { id: 'r12', name: 'Pico helado Deadeye', type: 'agua dulce', rarity: 'Raro', level: 7, zones: '7-8', biome: 'Montaña, Highland, Estepa', price: 1720, trend: '+65%', volume: 35 },
    { id: 'r13', name: 'Cangrejo de río bajo', type: 'agua dulce', rarity: 'Raro', level: 3, zones: '3-8', biome: 'Estepa, Bosque, Pantano', price: 720, trend: '+45%', volume: 92 },
    { id: 'r14', name: 'Cangrejo de Drybrook', type: 'agua dulce', rarity: 'Raro', level: 5, zones: '5-8', biome: 'Estepa, Bosque, Pantano', price: 1080, trend: '+52%', volume: 62 },
    { id: 'r15', name: 'Cangrejo de pozo de polvo', type: 'agua dulce', rarity: 'Raro', level: 7, zones: '7-8', biome: 'Estepa, Bosque, Pantano', price: 1820, trend: '+68%', volume: 32 },
    { id: 'r16', name: 'Calamar de costa poco profunda', type: 'Agua salada', rarity: 'Raro', level: 3, zones: '3-8', biome: 'Océano', price: 750, trend: '+47%', volume: 88 },
    { id: 'r17', name: 'Pulpo de aguas medias', type: 'Agua salada', rarity: 'Raro', level: 5, zones: '5-8', biome: 'Océano', price: 1120, trend: '+55%', volume: 58 },
    { id: 'r18', name: 'Kraken de aguas profundas', type: 'Agua salada', rarity: 'Raro', level: 7, zones: '7-8', biome: 'Océano', price: 1920, trend: '+72%', volume: 28 },
    { id: 'r19', name: 'Tiburón', type: 'Agua salada', rarity: 'Raro', level: 8, zones: '2 (Ciudades cruzadas) o 4-8', biome: 'Océano', price: 2200, trend: '+80%', volume: 22 },
    { id: 'r20', name: 'Pargo de niebla blanca', type: 'Agua', rarity: 'Raro', level: 3, zones: '3-8', biome: 'Caminos de Avalon, Nieblas', price: 850, trend: '+50%', volume: 75 },
    { id: 'r21', name: 'Pargo Clearhaze', type: 'Agua', rarity: 'Raro', level: 5, zones: '5-8', biome: 'Caminos de Avalon, Nieblas', price: 1280, trend: '+58%', volume: 48 },
    { id: 'r22', name: 'Pargo de niebla pura', type: 'Agua', rarity: 'Raro', level: 7, zones: '7-8', biome: 'Caminos de Avalon, Nieblas', price: 2150, trend: '+78%', volume: 25 }
  ], []);

  const allFish = useMemo(() => [...freshwaterFish, ...saltwaterFish, ...rareFish], [freshwaterFish, saltwaterFish, rareFish]);

  // Memoized filtered fish for performance
  const getFilteredFish = useMemo(() => {
    switch (selectedFilter) {
      case 'freshwater':
        return freshwaterFish;
      case 'saltwater':
        return saltwaterFish;
      case 'rare':
        return rareFish;
      case 'common':
        return [...freshwaterFish, ...saltwaterFish];
      default:
        return allFish;
    }
  }, [selectedFilter, freshwaterFish, saltwaterFish, rareFish, allFish]);

  // Cities data for map tabs
  const cities = useMemo(() => [
    {
      id: 'thetford',
      name: 'Thetford',
      color: 'green',
      description: 'Rica en recursos de agua dulce con pesca consistente',
      zones: [
        { name: 'Lago Central', level: 'T4-T6', fish: ['Trucha manchada', 'Lucio de escala'], coords: 'B5-C6' },
        { name: 'Río Norte', level: 'T3-T5', fish: ['Perca Albion', 'Carpa rayada'], coords: 'A3-B4' },
        { name: 'Pantano Sur', level: 'T5-T7', fish: ['Anguila verde', 'Almeja Greenmoor'], coords: 'D6-E7' }
      ]
    },
    {
      id: 'bridgewatch',
      name: 'Bridgewatch',
      color: 'blue',
      description: 'Perfecta para pesca marina con acceso a océano abierto',
      zones: [
        { name: 'Puerto Principal', level: 'T4-T6', fish: ['Bacalao azul', 'Salmón fuerte'], coords: 'F3-G4' },
        { name: 'Costa Este', level: 'T3-T5', fish: ['Platija plana', 'Caballa rayada'], coords: 'H4-I5' },
        { name: 'Aguas Profundas', level: 'T6-T8', fish: ['Kraken profundas', 'Tiburón'], coords: 'G6-H8' }
      ]
    },
    {
      id: 'martlock',
      name: 'Martlock',
      color: 'purple',
      description: 'Zonas de montaña con peces raros y de alto valor',
      zones: [
        { name: 'Lago Helado', level: 'T5-T7', fish: ['Deadeye helado', 'Ojo ciego'], coords: 'C2-D3' },
        { name: 'Arroyo Montaña', level: 'T4-T6', fish: ['Coldeye tierras', 'Acechador piedra'], coords: 'B1-C2' },
        { name: 'Cascada Alta', level: 'T6-T8', fish: ['Acechador truenos', 'Esturión río'], coords: 'D3-E4' }
      ]
    },
    {
      id: 'lymhurst',
      name: 'Lymhurst',
      color: 'orange',
      description: 'Zona forestal ideal para principiantes y pesca constante',
      zones: [
        { name: 'Estanque Bosque', level: 'T2-T4', fish: ['Rudd común', 'Perca Albion'], coords: 'E1-F2' },
        { name: 'Río Serpenteante', level: 'T3-T5', fish: ['Carpa rayada', 'Trucha manchada'], coords: 'F2-G3' },
        { name: 'Laguna Oculta', level: 'T5-T6', fish: ['Anguila verde', 'Cangrejo bajo'], coords: 'G3-H4' }
      ]
    },
    {
      id: 'fortsterling',
      name: 'Fort Sterling',
      color: 'cyan',
      description: 'Equilibrio perfecto entre agua dulce y salada',
      zones: [
        { name: 'Bahía Norte', level: 'T4-T6', fish: ['Salmón fuerte', 'Pez lobo'], coords: 'A6-B7' },
        { name: 'Delta Interior', level: 'T3-T5', fish: ['Arenque común', 'Bagre colgante'], coords: 'B7-C8' },
        { name: 'Estuario Sur', level: 'T5-T7', fish: ['Atún rojo', 'Pulpo medias'], coords: 'C8-D9' }
      ]
    },
    {
      id: 'caerleon',
      name: 'Caerleon',
      color: 'red',
      description: 'Zona negra de alto riesgo con las mejores recompensas',
      zones: [
        { name: 'Lago Maldito', level: 'T6-T8', fish: ['Anguila agua muerta', 'Almeja Blackbog'], coords: 'X5-Y6' },
        { name: 'Mar de Sangre', level: 'T7-T8', fish: ['Kraken profundas', 'Pez espada acero'], coords: 'Z6-Z8' },
        { name: 'Abismo Negro', level: 'T8', fish: ['Tiburón', 'Pargo niebla pura'], coords: 'Y8-Z9' }
      ]
    }
  ], []);

  // Optimized utility functions
  const getTrendDirection = useCallback((trend: string) => {
    return trend.startsWith('+') ? 'up' : 'down';
  }, []);

  const getRarityColor = useCallback((rarity: string) => {
    switch (rarity) {
      case 'Raro': return 'bg-purple-500/20 text-purple-400';
      case 'Común': return 'bg-gray-500/20 text-gray-400';
      default: return 'bg-blue-500/20 text-blue-400';
    }
  }, []);

  const handleFilterChange = useCallback((filter: string) => {
    setSelectedFilter(filter);
  }, []);

  const openCityModal = useCallback((cityId: string) => {
    setSelectedCity(cityId);
    setIsMapModalOpen(true);
  }, []);

  const closeCityModal = useCallback(() => {
    setIsMapModalOpen(false);
    setSelectedCity(null);
  }, []);

  const marketInsights = [
    {
      title: 'Demanda Alta de Raros',
      description: 'Los peces T6+ están subiendo 28% por actividad de guildas',
      type: 'opportunity',
      impact: 'Alto',
      timeframe: '2-3 días'
    },
    {
      title: 'Sobresaturación T4',
      description: 'Exceso de peces T4 está bajando los precios',
      type: 'warning',
      impact: 'Medio',
      timeframe: '1 semana'
    },
    {
      title: 'Tendencia Caerleon',
      description: 'Premium de zona negra aumentando con actualizaciones',
      type: 'info',
      impact: 'Alto',
      timeframe: 'Continuo'
    }
  ];

  const getInsightIcon = (type: string) => {
    switch (type) {
      case 'opportunity': return <Target className="h-5 w-5 text-green-400" />;
      case 'warning': return <AlertTriangle className="h-5 w-5 text-yellow-400" />;
      default: return <BarChart3 className="h-5 w-5 text-blue-400" />;
    }
  };

  const getCityColor = (color: string) => {
    const colors: { [key: string]: string } = {
      green: 'from-green-500 to-emerald-600',
      blue: 'from-blue-500 to-cyan-600',
      purple: 'from-purple-500 to-violet-600',
      orange: 'from-orange-500 to-amber-600',
      cyan: 'from-cyan-500 to-teal-600',
      red: 'from-red-500 to-rose-600'
    };
    return colors[color] || colors.blue;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-900 to-blue-900">
      <Navigation onAuthClick={() => setIsAuthModalOpen(true)} user={user} />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-12">

        {/* SECCIÓN 1: HEADER */}
        <section className="text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-4">
            Centro de Mercado
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Inteligencia de mercado, mapas interactivos e inventario completo de pesca para Albion Online
          </p>
        </section>

        {/* SECCIÓN 2: MONITOREO DE PRECIOS */}
        <section className="bg-gradient-to-r from-yellow-500/20 to-orange-500/20 rounded-xl border border-yellow-500/30 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold text-white flex items-center">
              <DollarSign className="h-7 w-7 mr-2 text-yellow-400" />
              Monitor de Precios Oro/Silver
            </h2>
            <button
              onClick={updatePrices}
              disabled={isUpdating}
              className="flex items-center px-4 py-2 bg-yellow-500/20 hover:bg-yellow-500/30 rounded-lg text-yellow-400 transition-colors disabled:opacity-50"
            >
              <RefreshCw className={`h-4 w-4 mr-2 ${isUpdating ? 'animate-spin' : ''}`} />
              {isUpdating ? 'Actualizando...' : 'Actualizar'}
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <p className="text-gray-300 mb-2">Tasa Actual</p>
              <p className="text-3xl font-bold text-yellow-400">{goldPrice.toLocaleString()}</p>
              <p className="text-sm text-gray-400">Silver por Gold</p>
            </div>
            <div className="text-center">
              <p className="text-gray-300 mb-2">Cambio 24h</p>
              <p className="text-2xl font-bold text-green-400 flex items-center justify-center">
                <TrendingUp className="h-5 w-5 mr-1" />
                +2.8%
              </p>
            </div>
            <div className="text-center">
              <p className="text-gray-300 mb-2">Predicción IA</p>
              <p className="text-lg font-semibold text-cyan-400">Tendencia Alcista</p>
              <p className="text-sm text-gray-400">Próximas 48h</p>
            </div>
          </div>
        </section>

        {/* SECCIÓN 3: INSIGHTS DE MERCADO */}
        <section>
          <h2 className="text-2xl font-bold text-white mb-6 flex items-center">
            <Zap className="h-6 w-6 mr-2 text-blue-400" />
            Análisis IA del Mercado
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {marketInsights.map((insight, index) => (
              <div key={index} className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-6">
                <div className="flex items-center justify-between mb-3">
                  {getInsightIcon(insight.type)}
                  <span className="text-sm text-gray-400">{insight.timeframe}</span>
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">{insight.title}</h3>
                <p className="text-gray-300 text-sm mb-3">{insight.description}</p>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-500">Impacto</span>
                  <span className={`text-sm font-medium ${
                    insight.impact === 'Alto' ? 'text-red-400' :
                    insight.impact === 'Medio' ? 'text-yellow-400' : 'text-blue-400'
                  }`}>
                    {insight.impact}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* SECCIÓN 4: MAPAS INTERACTIVOS CON OVERLAYS */}
        <section>
          <h2 className="text-2xl font-bold text-white mb-6 flex items-center">
            <Map className="h-6 w-6 mr-2 text-green-400" />
            Mapas de Zonas de Pesca
          </h2>

          {/* Grid de Ciudades */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {cities.map((city) => (
              <div
                key={city.id}
                className="group bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-6 hover:bg-white/10 transition-all duration-300 cursor-pointer transform hover:scale-105"
                onClick={() => openCityModal(city.id)}
              >
                <div className="flex items-center justify-between mb-4">
                  <div className={`p-3 rounded-xl bg-gradient-to-r ${getCityColor(city.color)} bg-opacity-20 group-hover:bg-opacity-30 transition-all`}>
                    <NavIcon className="h-6 w-6 text-white" />
                  </div>
                  <MapPin className="h-5 w-5 text-gray-400 group-hover:text-white transition-colors" />
                </div>

                <h3 className="text-xl font-bold text-white mb-2 group-hover:text-blue-400 transition-colors">
                  {city.name}
                </h3>
                <p className="text-gray-300 text-sm mb-4 line-clamp-2">
                  {city.description}
                </p>

                <div className="flex items-center justify-between text-xs text-gray-400">
                  <span className="flex items-center">
                    <Fish className="h-4 w-4 mr-1" />
                    {city.zones.length} zonas
                  </span>
                  <span className="group-hover:text-blue-400 transition-colors">
                    Ver detalles →
                  </span>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* SECCIÓN 5: INVENTARIO DE PESCA */}
        <section>
          <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
            <h2 className="text-2xl font-bold text-white flex items-center mb-4 md:mb-0">
              <Fish className="h-6 w-6 mr-2 text-green-400" />
              Inventario de Pesca Completo
            </h2>

            {/* Filtros */}
            <div className="flex flex-wrap gap-2">
              {[
                { id: 'all', label: 'Todos', icon: BarChart3 },
                { id: 'common', label: 'Comunes', icon: Fish },
                { id: 'freshwater', label: 'Agua Dulce', icon: Waves },
                { id: 'saltwater', label: 'Agua Salada', icon: Waves },
                { id: 'rare', label: 'Raros', icon: Zap }
              ].map((filter) => {
                const Icon = filter.icon;
                return (
                  <button
                    key={filter.id}
                    onClick={() => handleFilterChange(filter.id)}
                    className={`flex items-center px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                      selectedFilter === filter.id
                        ? filter.id === 'rare' ? 'bg-purple-600 text-white' : 'bg-blue-600 text-white'
                        : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                    }`}
                  >
                    <Icon className="h-4 w-4 mr-2" />
                    {filter.label}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-800/50">
                  <tr>
                    <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Nivel</th>
                    <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Nombre</th>
                    <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Tipo</th>
                    <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Rareza</th>
                    <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Zonas</th>
                    {selectedFilter === 'rare' && (
                      <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Bioma</th>
                    )}
                    <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Precio</th>
                    <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Tendencia</th>
                    <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Volumen</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-800/50">
                  {getFilteredFish.map((fish) => (
                    <tr key={fish.id} className="hover:bg-white/5 transition-colors">
                      <td className="px-6 py-4">
                        <span className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-blue-500/20 text-blue-400 font-bold">
                          T{fish.level}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-white font-medium">{fish.name}</div>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`px-2 py-1 text-xs rounded ${
                          fish.type === 'agua dulce' ? 'bg-cyan-500/20 text-cyan-400' :
                          fish.type === 'Agua salada' ? 'bg-blue-500/20 text-blue-400' :
                          'bg-indigo-500/20 text-indigo-400'
                        }`}>
                          {fish.type}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`px-2 py-1 text-xs rounded font-medium ${getRarityColor(fish.rarity)}`}>
                          {fish.rarity}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-gray-300 text-sm">{fish.zones}</td>
                      {selectedFilter === 'rare' && (
                        <td className="px-6 py-4 text-gray-300 text-xs">{(fish as any).biome}</td>
                      )}
                      <td className="px-6 py-4 text-white font-semibold">{fish.price} 🪙</td>
                      <td className="px-6 py-4">
                        <span className={`flex items-center ${
                          getTrendDirection(fish.trend) === 'up' ? 'text-green-400' : 'text-red-400'
                        }`}>
                          {getTrendDirection(fish.trend) === 'up' ? (
                            <TrendingUp className="h-4 w-4 mr-1" />
                          ) : (
                            <TrendingDown className="h-4 w-4 mr-1" />
                          )}
                          {fish.trend}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-gray-300">{fish.volume.toLocaleString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="mt-4 text-center text-gray-400 text-sm">
            Mostrando {getFilteredFish.length} de {allFish.length} especies de peces disponibles
          </div>
        </section>

      </div>

      {/* Modal de Información Detallada de Ciudad */}
      {isMapModalOpen && selectedCity && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-gray-900 rounded-2xl border border-gray-700 max-w-6xl w-full max-h-[90vh] overflow-hidden flex flex-col">
            {cities
              .filter(city => city.id === selectedCity)
              .map((city) => (
                <div key={city.id} className="flex flex-col h-full">
                  {/* Header del Modal */}
                  <div className={`p-6 bg-gradient-to-r ${getCityColor(city.color)} bg-opacity-20 border-b border-gray-700`}>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className={`p-4 rounded-xl bg-gradient-to-r ${getCityColor(city.color)} bg-opacity-40`}>
                          <Compass className="h-8 w-8 text-white" />
                        </div>
                        <div>
                          <h2 className="text-3xl font-bold text-white mb-2">{city.name}</h2>
                          <p className="text-gray-200">{city.description}</p>
                        </div>
                      </div>
                      <button
                        onClick={closeCityModal}
                        className="p-2 rounded-lg bg-gray-700/50 hover:bg-gray-700 text-gray-300 hover:text-white transition-colors"
                      >
                        <X className="h-6 w-6" />
                      </button>
                    </div>
                  </div>

                  {/* Contenido Scrolleable */}
                  <div className="flex-1 overflow-y-auto p-6">
                    <div className="mb-6">
                      <h3 className="text-xl font-semibold text-white mb-4 flex items-center">
                        <MapPin className="h-5 w-5 mr-2 text-blue-400" />
                        Zonas de Pesca Disponibles
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {city.zones.map((zone, idx) => (
                          <div key={idx} className="bg-gray-800/50 rounded-xl p-6 border border-gray-700 hover:bg-gray-800/70 transition-colors">
                            <div className="flex items-center justify-between mb-4">
                              <h4 className="text-lg font-semibold text-white">{zone.name}</h4>
                              <div className="flex items-center space-x-2">
                                <span className="text-xs bg-blue-500/20 text-blue-400 px-3 py-1 rounded-full font-medium">
                                  {zone.coords}
                                </span>
                                <span className={`text-xs px-3 py-1 rounded-full font-medium ${
                                  zone.level.includes('T6') || zone.level.includes('T7') || zone.level.includes('T8')
                                    ? 'bg-red-500/20 text-red-400'
                                    : zone.level.includes('T4') || zone.level.includes('T5')
                                    ? 'bg-yellow-500/20 text-yellow-400'
                                    : 'bg-green-500/20 text-green-400'
                                }`}>
                                  {zone.level}
                                </span>
                              </div>
                            </div>

                            <div className="mb-4">
                              <span className="text-sm text-gray-400 mb-2 block">Nivel de Dificultad:</span>
                              <div className="flex items-center space-x-2">
                                <div className="flex-1 bg-gray-700 rounded-full h-2">
                                  <div
                                    className={`h-2 rounded-full ${
                                      zone.level.includes('T6') || zone.level.includes('T7') || zone.level.includes('T8')
                                        ? 'bg-red-500 w-5/6'
                                        : zone.level.includes('T4') || zone.level.includes('T5')
                                        ? 'bg-yellow-500 w-3/6'
                                        : 'bg-green-500 w-2/6'
                                    }`}
                                  />
                                </div>
                                <span className="text-xs text-gray-400">
                                  {zone.level.includes('T6') || zone.level.includes('T7') || zone.level.includes('T8')
                                    ? 'Difícil'
                                    : zone.level.includes('T4') || zone.level.includes('T5')
                                    ? 'Medio'
                                    : 'Fácil'}
                                </span>
                              </div>
                            </div>

                            <div>
                              <span className="text-sm text-gray-400 mb-3 block">Peces Disponibles:</span>
                              <div className="grid grid-cols-2 gap-2">
                                {zone.fish.map((fish, fishIdx) => (
                                  <div key={fishIdx} className="flex items-center space-x-2 bg-gray-700/30 rounded-lg p-2">
                                    <Fish className="h-4 w-4 text-blue-400 flex-shrink-0" />
                                    <span className="text-sm text-gray-300 truncate">{fish}</span>
                                  </div>
                                ))}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Información Adicional */}
                    <div className="bg-gradient-to-r from-gray-800/50 to-gray-700/50 rounded-xl p-6 border border-gray-600">
                      <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
                        <Target className="h-5 w-5 mr-2 text-green-400" />
                        Consejos para {city.name}
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <h4 className="text-sm font-medium text-green-400 mb-2">✓ Recomendaciones</h4>
                          <ul className="text-sm text-gray-300 space-y-1">
                            {city.color === 'green' && (
                              <>
                                <li>• Perfecto para principiantes</li>
                                <li>• Zonas seguras con buena rentabilidad</li>
                                <li>• Abundante agua dulce</li>
                              </>
                            )}
                            {city.color === 'blue' && (
                              <>
                                <li>• Excelente para pesca marina</li>
                                <li>• Acceso directo al océano</li>
                                <li>• Diversidad de especies</li>
                              </>
                            )}
                            {city.color === 'purple' && (
                              <>
                                <li>• Peces raros y valiosos</li>
                                <li>• Zonas montañosas únicas</li>
                                <li>• Alta rentabilidad</li>
                              </>
                            )}
                            {city.color === 'orange' && (
                              <>
                                <li>• Ambiente forestal tranquilo</li>
                                <li>• Ideal para sesiones largas</li>
                                <li>• Rutas de escape múltiples</li>
                              </>
                            )}
                            {city.color === 'cyan' && (
                              <>
                                <li>• Balance perfecto</li>
                                <li>• Agua dulce y salada</li>
                                <li>• Versatilidad máxima</li>
                              </>
                            )}
                            {city.color === 'red' && (
                              <>
                                <li>• Zona negra de élite</li>
                                <li>• Máximas recompensas</li>
                                <li>• Solo para expertos</li>
                              </>
                            )}
                          </ul>
                        </div>
                        <div>
                          <h4 className="text-sm font-medium text-red-400 mb-2">⚠ Precauciones</h4>
                          <ul className="text-sm text-gray-300 space-y-1">
                            {city.color === 'red' ? (
                              <>
                                <li>• Alto riesgo de PvP</li>
                                <li>• Requiere equipo T6+</li>
                                <li>• Nunca vayas solo</li>
                              </>
                            ) : city.color === 'purple' ? (
                              <>
                                <li>• Zonas de nivel alto</li>
                                <li>• Clima impredecible</li>
                                <li>• Lleva equipo de montaña</li>
                              </>
                            ) : (
                              <>
                                <li>• Compite horarios peak</li>
                                <li>• Vigila otros jugadores</li>
                                <li>• Ten rutas de escape</li>
                              </>
                            )}
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Footer del Modal */}
                  <div className="p-6 border-t border-gray-700 bg-gray-800/30">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4 text-sm text-gray-400">
                        <span className="flex items-center">
                          <Users className="h-4 w-4 mr-1" />
                          Recomendado: {city.color === 'red' ? 'Expertos' : city.color === 'purple' ? 'Avanzado' : 'Todos los niveles'}
                        </span>
                        <span className="flex items-center">
                          <Fish className="h-4 w-4 mr-1" />
                          {city.zones.length} zonas de pesca
                        </span>
                      </div>
                      <button
                        onClick={closeCityModal}
                        className={`px-6 py-2 bg-gradient-to-r ${getCityColor(city.color)} text-white rounded-lg hover:opacity-90 transition-opacity font-medium`}
                      >
                        Entendido
                      </button>
                    </div>
                  </div>
                </div>
              ))}
          </div>
        </div>
      )}

      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onLogin={handleLogin}
      />
    </div>
  );
}