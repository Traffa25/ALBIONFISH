import { useState } from 'react';
import { Fish, TrendingUp, Map, Calculator, Bot, Coins, Crown, Zap } from 'lucide-react';
import Navigation from '../components/Navigation';
import AuthModal from '../components/AuthModal';
import OptimizedAIChat from '../components/OptimizedAIChat';
import { useLanguage } from '../contexts/LanguageContext';

export default function Dashboard() {
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [user, setUser] = useState(null);
  const { t } = useLanguage();

  const handleLogin = (userData: any) => {
    setUser(userData);
  };

  const stats = [
    { label: t('dashboard.stats.caught'), value: '12,547', icon: Fish, color: 'blue' },
    { label: t('dashboard.stats.earned'), value: '2.8M', icon: Coins, color: 'yellow' },
    { label: t('dashboard.stats.zone'), value: 'Thetford', icon: Map, color: 'green' },
    { label: t('dashboard.stats.profit'), value: '+24.5%', icon: TrendingUp, color: 'purple' },
  ];

  const features = [
    {
      title: 'Interactive Maps',
      description: 'Explore fishing zones across all Albion cities with real-time information',
      icon: Map,
      color: 'blue'
    },
    {
      title: 'Profit Calculator',
      description: 'Calculate optimal fishing strategies and expected returns',
      icon: Calculator,
      color: 'green'
    },
    {
      title: 'AI Assistant',
      description: 'Get personalized recommendations and answer to your questions',
      icon: Bot,
      color: 'purple'
    },
    {
      title: 'Market Intelligence',
      description: 'Real-time pricing data and market trends analysis',
      icon: TrendingUp,
      color: 'orange'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-900 to-blue-900">
      <Navigation onAuthClick={() => setIsAuthModalOpen(true)} user={user} />

      <div className="relative overflow-hidden">
        {/* Animated Background Elements */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute -top-40 -right-40 w-80 h-80 rounded-full bg-blue-500/10 blur-3xl animate-pulse"></div>
          <div className="absolute -bottom-40 -left-40 w-80 h-80 rounded-full bg-cyan-500/10 blur-3xl animate-pulse delay-1000"></div>
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 rounded-full bg-blue-400/5 blur-3xl animate-pulse delay-500"></div>
        </div>

        {/* Hero Section */}
        <div className="relative px-4 sm:px-6 lg:px-8 pt-20 pb-16">
          <div className="max-w-7xl mx-auto text-center">
            <div className="inline-flex items-center px-4 py-2 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-sm font-medium mb-8">
              <Zap className="h-4 w-4 mr-2" />
              AI-Powered Fishing Assistant for Albion Online
            </div>

            <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 leading-tight">
              Master Albion's
              <span className="block bg-gradient-to-r from-blue-400 via-cyan-400 to-blue-500 bg-clip-text text-transparent">
                Fishing Waters
              </span>
            </h1>

            <p className="text-xl text-gray-300 mb-12 max-w-3xl mx-auto leading-relaxed">
              Advanced tools, AI-powered insights, and real-time market data to maximize your fishing profits in Albion Online. From zone optimization to inventory management, we've got you covered.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="px-8 py-4 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white font-semibold rounded-xl transition-all duration-300 transform hover:scale-105 shadow-xl shadow-blue-500/25">
                Start Fishing Assistant
              </button>
              <button className="px-8 py-4 bg-white/10 hover:bg-white/20 text-white font-semibold rounded-xl border border-white/20 backdrop-blur-sm transition-all duration-300">
                View Live Demo
              </button>
            </div>
          </div>
        </div>

        {/* Stats Section */}
        <div className="relative px-4 sm:px-6 lg:px-8 pb-16">
          <div className="max-w-7xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {stats.map((stat, index) => {
                const Icon = stat.icon;
                return (
                  <div key={index} className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-6 hover:bg-white/10 transition-all duration-300">
                    <div className="flex items-center justify-between mb-4">
                      <div className={`p-3 rounded-lg bg-${stat.color}-500/20`}>
                        <Icon className={`h-6 w-6 text-${stat.color}-400`} />
                      </div>
                      <span className={`text-2xl font-bold text-${stat.color}-400`}>
                        {stat.value}
                      </span>
                    </div>
                    <p className="text-gray-300 font-medium">{stat.label}</p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Features Grid */}
        <div className="relative px-4 sm:px-6 lg:px-8 pb-20">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold text-white mb-4">
                Everything You Need to Dominate
              </h2>
              <p className="text-xl text-gray-400 max-w-2xl mx-auto">
                Comprehensive tools designed specifically for Albion Online fishing optimization
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {features.map((feature, index) => {
                const Icon = feature.icon;
                return (
                  <div key={index} className="group bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-8 hover:bg-white/10 transition-all duration-300 hover:scale-105">
                    <div className={`inline-flex p-3 rounded-lg bg-${feature.color}-500/20 mb-6`}>
                      <Icon className={`h-8 w-8 text-${feature.color}-400`} />
                    </div>
                    <h3 className="text-2xl font-semibold text-white mb-4 group-hover:text-blue-400 transition-colors">
                      {feature.title}
                    </h3>
                    <p className="text-gray-300 leading-relaxed">
                      {feature.description}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Premium CTA */}
        <div className="relative px-4 sm:px-6 lg:px-8 pb-20">
          <div className="max-w-4xl mx-auto">
            <div className="bg-gradient-to-r from-yellow-500/20 via-orange-500/20 to-yellow-500/20 rounded-2xl border border-yellow-500/30 p-8 md:p-12 text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-yellow-500/20 rounded-full mb-6">
                <Crown className="h-8 w-8 text-yellow-400" />
              </div>
              <h3 className="text-3xl font-bold text-white mb-4">
                Unlock Premium Features
              </h3>
              <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
                Get access to advanced AI recommendations, real-time market alerts, and exclusive fishing strategies
              </p>
              <button className="px-8 py-4 bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-black font-semibold rounded-xl transition-all duration-300 transform hover:scale-105 shadow-xl shadow-yellow-500/25">
                Upgrade to Premium
              </button>
            </div>
          </div>
        </div>
      </div>

      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onLogin={handleLogin}
      />

      <OptimizedAIChat />
    </div>
  );
}