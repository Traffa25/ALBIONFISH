import react from '@vitejs/plugin-react';
import { defineConfig } from 'vite';

const webjourneyPluginScriptHost = 'https://app.webjourney.pro';

// https://vite.dev/config/
export default defineConfig({
  plugins: [
    react(),
    {
      name: 'inject-webjourney-plugin',
      transformIndexHtml(html) {
        return html.replace(
          '</body>',
          `    <script src="${webjourneyPluginScriptHost}/plugins/plugin.iife.js" defer></script>\n  </body>`
        );
      }
    }
  ],
  server: {
    hmr: {
      overlay: false, // stops the red error screen in browser
    },
    watch: {
      // Ignore .webjourney folder
      ignored: ['**/.webjourney/**']
    }
  },
});
